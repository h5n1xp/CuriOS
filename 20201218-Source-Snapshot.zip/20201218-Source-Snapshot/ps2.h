//
//  ps_2.h
//  
//
//  Created by Matt Parsons on 22/09/2020.
//
//

#ifndef ps_2_h
#define ps_2_h

#include "stdheaders.h"

void InitPS2();

#endif
