qemu-system-x86_64 -vga std -m 1024 -hda ./disk.img -boot menu=off
