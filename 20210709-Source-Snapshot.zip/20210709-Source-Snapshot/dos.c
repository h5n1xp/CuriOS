//
//  dos.c
//
//  Created by Matt Parsons on 20/11/2020.
//  Copyright © 2020 Matt Parsons. All rights reserved.
//

#include "dos.h"
#include "memory.h"

#include "ata.h"
#include "fat_handler.h"    //DOS calls the FAT functions directly until we have a proper handler
#include "string.h"

#include "SystemLog.h"

dos_t dos;

dosEntry_t* bootDOSEntry;   // boot disk dos entry


file_t* Open(char* fileName, uint64_t attributes){
    
    return NULL;
    
    debug_write_string("DOS.Library: Open() Called on file ");
    debug_write_string(fileName);
    debug_write_string(" - ");
    debug_write_hex(attributes);
    debug_write_string("\n");
    
    return NULL;
    
}


void InitDOS(library_t* library){
    //called by AddLibrary(), does the library set up.
    
    InitList(&dos.dosList);
    library->node.name = "dos.library";
 
    //The DOS.library will need to access the disks
    //setup the ata device
    //LoadATADevice();
    //executive->AddDevice((device_t*)&ata);
    
    
    

    
    //The boot disk will be FAT32
    LoadFATHandler();
    executive->AddDevice((device_t*)&fatHandler);
    
    debug_write_string("DOS Library: Setting up hard disks...\n");
    
    //Add a FAT file system handler to DOS on top of the ATA device, first partition.
    node_t* node                    = executive->Alloc(sizeof(dosEntry_t));
    node->name                      = "DH0";
    bootDOSEntry                    = (dosEntry_t*)node;
    bootDOSEntry->handlerName       = "fat.handler";
    bootDOSEntry->handlerNumber     = 0;
    bootDOSEntry->deviceName        = "ata.device";
    bootDOSEntry->unitNumber        = 0;
    dos.AddDosEntry(bootDOSEntry);

    // Use the current task context DOSPort for the IORequest, which should be the boot task at this stage.
    
    //This will be NULL as nothing can have Opened the DOS library yet!
    messagePort_t* dosPort = executive->CreatePort("DOS Port"); // Cannot do ANY DOS operations AT ALL without a DOS PORT! Open Dos Library does this automatically
    executive->thisTask->dosPort = dosPort;
    

    
    ioRequest_t* req = executive->CreateIORequest(dosPort, sizeof(ioRequest_t));
    bootDOSEntry->message = req;
    
    
    //now we have a valid IO Request, open the ata.device
    if(executive->OpenDevice("ata.device",0,req,0)){
        debug_write_string("DOS Library: No Hard Disk!!!\n");
        return;
    }
    

    
    //Allocate a one 512kb buffer for the DOS Entry IORequest
    uint8_t* buffer = executive->AllocMem(512,0);
    
    //set up intial request for the first sector, this will get the MBR data
    req->data = buffer;
    
    //get location of first partition, which will be our Boot partition
    getPartitionData(bootDOSEntry, 0);

    
}






void OpenLib(library_t* lib){
    //dos.library.openCount +=1;
    lib->openCount +=1;
    
    //initilise the DOS Message port of the calling task
    task_t* task  = executive->thisTask;
    
    //The boot task get a DOS Port as part of the Library Initilisation, but no other task will
    if(task->dosPort == NULL){
        task->dosPort = executive->CreatePort("DOS Port");
    }
}


void CloseLib(library_t* lib){
    //dos.library.openCount -=1;
    lib->openCount -=1;
    
    //remove DOS message port
    task_t* task  = executive->thisTask;
    executive->DeletePort((messagePort_t*)task->dosPort);
    debug_write_string("DOS Opened by ");
    debug_write_string(task->node.name);
    debug_putchar('\n');
}

void AddDosEntry(dosEntry_t* entry){

    //need to setup the requested unit.
    
    AddTail(&dos.dosList,(node_t*) entry);
    
    /*
    ioRequest_t* handlerRequest = executive->CreateIORequest(NULL,sizeof(ioRequest_t));
    uint32_t error = executive->OpenDevice(entry->handlerName,entry->handlerNumber,handlerRequest,0);
    
    if(error == DEVICE_ERROR_DEVICE_NOT_FOUND){
        debug_write_string("Handler Not Found\n");
        return;
    }
    
    //if we get this far we know the fat handler has opened.
    fatHandler_t* handler = (fatHandler_t*)handlerRequest->device;
    handler->SetHandler(entry);
     */
     
}


void LoadDOSLibrary(){
    
    dos.library.Init    = InitDOS;
    dos.library.Open    = OpenLib;
    dos.library.Close   = CloseLib;
    dos.AddDosEntry     = AddDosEntry;
    dos.Open            = Open;
    
}
