//
//  fat_handler.h
//
//  Created by Matt Parsons on 27/11/2020.
//  Copyright © 2020 Matt Parsons. All rights reserved.
//

#ifndef fat_handler_h
#define fat_handler_h

#include "stdheaders.h"
#include "device.h"
#include "dos.h"

typedef struct{
    device_t device;
    void (*SetHandler)(dosEntry_t* entry);
} fatHandler_t;

typedef struct {
    char name[64];
    uint32_t cluster;
    uint32_t flags;
    uint32_t fileSize;
    bool isDir;
    bool isHidden;
} directoryEntry_t;



extern fatHandler_t fatHandler;
void LoadFATHandler(void);


//Internal functions exposed while the hander features arn't used.
void getPartitionData(dosEntry_t* entry, int partitionNumber);
void getVolumeBootRecord(dosEntry_t* entry);
void readBlock(dosEntry_t* entry, uint32_t block);

void SetHandler(dosEntry_t*);
uint32_t FATGetPartitionLBA(int partitionNumber);



#endif /* fat_handler_h */
