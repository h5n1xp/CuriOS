//
//  dos.c
//
//  Created by Matt Parsons on 20/11/2020.
//  Copyright © 2020 Matt Parsons. All rights reserved.
//

#include "dos.h"
#include "memory.h"

dos_t dos;

void InitDOS(library_t* library){
    
    InitList(&dos.dosList);
    library->node.name = "dos.library";
    
    
}

void OpenLib(library_t* lib){
    dos.library.openCount +=1;
}


void AddDosEntry(dosEntry_t* entry){

    //need to setup the iorequests etc...
    
    AddTail(&dos.dosList,(node_t*) entry);
    
}

void InitDOSLibrary(){
    
    dos.library.Init    = InitDOS;
    dos.library.Open    = OpenLib;
    dos.AddDosEntry     = AddDosEntry;
    
}
