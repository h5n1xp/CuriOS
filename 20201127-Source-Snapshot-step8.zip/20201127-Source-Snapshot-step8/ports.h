//
//  ports.h
//
//  Created by Matt Parsons on 02/11/2020.
//  Copyright © 2020 Matt Parsons. All rights reserved.
//

#ifndef ports_h
#define ports_h

#include "stdheaders.h"
#include "list.h"
#include "task.h"

typedef struct{
    node_t node;
    task_t* owner;
    uint64_t sigNum;
    list_t messageList;
} messagePort_t;


typedef struct{
    node_t node;
    uint64_t timestamp;
    messagePort_t* replyPort;
} message_t;


messagePort_t* CreatePort(char* name);
void DeletePort(messagePort_t* port);
messagePort_t* FindPort(char* name);

message_t* GetMessage(messagePort_t* port);
void PutMessage(messagePort_t* port, message_t* message);
void ReplyMessage(message_t* message);

void AddPort(messagePort_t* port);
void RemovePort(messagePort_t* port);

message_t* WaitPort(messagePort_t* port);

#endif /* ports_h */
