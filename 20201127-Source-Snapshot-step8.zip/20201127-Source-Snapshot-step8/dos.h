//
//  dos.h
//
//  Created by Matt Parsons on 20/11/2020.
//  Copyright © 2020 Matt Parsons. All rights reserved.
//

#ifndef dos_h
#define dos_h

#include "stdheaders.h"
#include "library.h"
#include "device.h"
#include "list.h"

typedef struct{
    node_t node;
    char* handlerName;
    char* deviceName;
    uint32_t unitNumber;
    device_t* handler;
    uint32_t number;
    device_t* device;
    unit_t* unit;
}dosEntry_t;

typedef struct{
    library_t library;
    list_t dosList;
    void (*AddDosEntry)(dosEntry_t* entry);
}dos_t;


extern dos_t dos;


void InitDOSLibrary();

#endif /* dos_h */
