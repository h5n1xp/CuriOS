qemu-system-x86_64 -d int -vga std -m 1024 -hda ./disk.img -boot menu=off
