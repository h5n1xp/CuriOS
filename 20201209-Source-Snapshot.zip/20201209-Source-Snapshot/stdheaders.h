//
//  stdheaders.h
//  
//
//  Created by Matt Parsons on 22/09/2020.
//
//

#ifndef stdheaders_h
#define stdheaders_h

#include <stdbool.h>
#include <stddef.h>
#include <stdint.h>

//#warning void_ptr will need to be redefined on 64bit system
typedef uint32_t void_ptr; 


#endif
