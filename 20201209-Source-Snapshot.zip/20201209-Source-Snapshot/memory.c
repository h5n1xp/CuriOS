//
//  memory.c
//
//  Created by Matt Parsons on 25/10/2020.
//  Copyright © 2020 Matt Parsons. All rights reserved.
//

#include "memory.h"
#include "SystemLog.h"

executive_t* executive;


// a lock is a primative type, so needs to be included for anything that accesses memory


// This lock lowers the resting task to match the locking task - which seems more stable at the moment
inline void Lock(lock_t* lock){
    

    if(__atomic_test_and_set(&lock->isLocked, __ATOMIC_ACQUIRE)){
        
        //to avoid a  priority inversion match the waiting task priority with the locking task.
        int64_t taskPri = executive->thisTask->node.priority;
        
        //only match if the locking task is lower priority;
        if(lock->lockingTaskPri<taskPri){
            executive->thisTask->node.priority = lock->lockingTaskPri;
        }

        while (__atomic_test_and_set(&lock->isLocked, __ATOMIC_ACQUIRE)) {
            executive->Reschedule();
        }

        
        executive->thisTask->node.priority = taskPri;
    
    }
    
 
    lock->lockingTaskPri = executive->thisTask->node.priority;
  
}
 
 inline void FreeLock(lock_t* lock){
 
 __atomic_clear(&lock->isLocked, __ATOMIC_RELEASE);
 
 }
 

/*
// This lock raises the locking task to match the requesting task - seems to cause random lock ups...
inline void Lock(lock_t* lock){
    
    
    if(__atomic_test_and_set(&lock->isLocked, __ATOMIC_ACQUIRE)){
        
        //to avoid a  priority inversion match the waiting task priority with the locking task.
        int64_t taskPri = executive->thisTask->node.priority;
        task_t* lockingTask = lock->lockingTask;
        
        //only match if the locking task is lower priority;
        if(taskPri > lockingTask->node.priority){

            executive->Forbid();
            Remove(&executive->taskReady,(node_t*)lockingTask);
            lockingTask->node.priority = taskPri;
            Enqueue(&executive->taskReady,(node_t*)lockingTask);
            executive->Permit();
            
        }
        
        while (__atomic_test_and_set(&lock->isLocked, __ATOMIC_ACQUIRE)) {
            executive->Reschedule();
        }
        
    }
    
    lock->lockingTask = executive->thisTask;
    lock->lockingTaskPri = executive->thisTask->node.priority;  // save locking task's normal priority
    
}




inline void FreeLock(lock_t* lock){

    executive->thisTask->node.priority = lock->lockingTaskPri; // restore locking task's normal priority
    
    __atomic_clear(&lock->isLocked, __ATOMIC_RELEASE);

}
*/


inline bool TestLock(lock_t* lock){
    
    if(__atomic_test_and_set(&lock->isLocked, __ATOMIC_ACQUIRE)){
        return true;
    }
    
    __atomic_clear(&lock->isLocked, __ATOMIC_RELEASE);
    return false;
}




//lock_t memLock;

node_t* KAlloc(size_t size){
    
    lock_t* memLock = &executive->freeList.lock;
    
    Lock(memLock);
    
    //add on memory header size;
    //size +=sizeof(node_t);        // removed since alloc should only be use to allocate OS objects
    
    //need to align on 8 byte boundary
    size += 7;
    size &= 0xFFFFFFFFFFFFFFF8;
    
    list_t* freelist = &executive->freeList;
    
    node_t* freeblock = freelist->head;

    
    do{
        //exact match
        if(freeblock->size == size){
            Remove(freelist, freeblock);
            freeblock->type = MEM_TYPE_ALLOC;
            freeblock->nodeType = NODE_UNKNOWN;
            freeblock->next = NULL;
            freeblock->prev = NULL;
            
            FreeLock(memLock);
            return freeblock;
        }
        
        if(freeblock->size > size + (sizeof(node_t) * 2 ) ){
            break;
        }
        
        freeblock = freeblock->next;
    }while(freeblock->next != NULL);
    

    //No block big enough
    if(freeblock->next == NULL){
        FreeLock(memLock);
        return NULL;
    }

           
           
    uint8_t* temp = (uint8_t*)freeblock;
    temp += freeblock->size;
    
    temp -= size;
    
    node_t* newBlock = (node_t*)temp;
    
    newBlock->size = size;
    newBlock->priority = 0;
    newBlock->flags = 0;
    newBlock->type = MEM_TYPE_ALLOC;
    newBlock->nodeType = NODE_UNKNOWN;
    newBlock->nextContigious = freeblock->nextContigious;
    

    
    freeblock->size -= size;
    freeblock->nextContigious = newBlock;

    
    FreeLock(memLock);
    return newBlock;
    
}


void Coalesce(node_t* node){
    
    node_t* contig = node->nextContigious;
    
    if(contig == NULL){
        return;
    }
    
    if( (contig->type & MEM_TYPE_ALLOC) == MEM_TYPE_ALLOC){
        return;
    }
    

    Coalesce(contig);
    
    Remove(&executive->freeList,contig);
    node->nextContigious = contig->nextContigious;
    node->size +=contig->size;
    
    
}


void DefragMem(){
    
     lock_t* memLock = &executive->freeList.lock;
     Lock(memLock);
    
    node_t* node = executive->freeList.head;
    
    while (node->next != NULL) {
        Coalesce(node);
        node = node->next;
    }
    
    FreeLock(memLock);
}

void KDealloc(node_t* node){
    
    lock_t* memLock = &executive->freeList.lock;
    
    Lock(memLock);
    
    node->type = MEM_TYPE_FREE;
    node->nodeType = NODE_MEMORY;
    node->priority = 0;
    node->flags = 0;
    
    Coalesce(node);
    
    list_t* freelist = &executive->freeList;
    
    node_t* pred = freelist->pred;
        

    if(pred->prev==NULL){
        AddHead(freelist, node);
    }
    
    while (pred->prev != NULL) {
        
        
        
        if(pred->size < node->size){
            
            Insert(freelist, node, pred);
            
            FreeLock(memLock);
            return;
            
        }
        
        
        
        pred = pred->prev;
    }
    
    AddHead(freelist, node);
    FreeLock(memLock);
}

void* AllocMem(size_t size, uint64_t type){

    // random check, to suppress compiler warning while we only have one type of ram.
    if(type == 68000){
        return NULL;
    }
    
    //add on memory header size;
    size +=sizeof(node_t);
    
    node_t* node = KAlloc(size);
    
    //add this memory allocation to the calling task's memory list
    if(executive->thisTask != NULL){
        AddTail(&executive->thisTask->memoryList,node);
    }
    
    node +=1;
    
    
    return (void*)node;
    
}

void FreeMem(void* pointer){
    
    node_t* node = (node_t*)pointer;
    
    node -= 1;
    
    //remove this memory allocation from the calling task's memory list
    if(executive->thisTask != NULL){
        Remove(&executive->thisTask->memoryList,node);
    }
    
    KDealloc(node);
    
}

library_t* OpenLibrary(char* name,uint64_t version){

    library_t* library = (library_t*) FindName(&executive->libraryList,name);
    
    
    //need to check the verion number before returning;
    if(library->version < version){
        //versions don't matter at this time....
    }
    
    
    library->Open(library);
    return library;
    
}


void AddLibrary(library_t* library){
    
    library->Init(library);
    
    AddTail(&executive->libraryList,(node_t*)library);
    
}

void AddDevice(device_t* device){
    
    device->library.Init(&device->library);
    
    /* // now isn't the correct time to check to see what units the device may have.
    if(device->unitList.count < 1 ){
        debug_write_string("Device Open failure: No units!!");
    }
    */
    
    AddTail(&executive->deviceList,(node_t*)device);
    
}



uint64_t OpenDevice(char* name,uint32_t unitNumber,ioRequest_t* ioRequest,uint64_t flags){
    
    node_t* node = FindName(&executive->deviceList,name);
    
    if(node==NULL){
        return DEVICE_ERROR_DEVICE_NOT_FOUND;
    }
    
    device_t* device = (device_t*)node;
    device->library.Open(&device->library);
    ioRequest->device = device;
    
    if(node==NULL){
        ioRequest->error = -1;
        return DEVICE_ERROR_DEVICE_NOT_FOUND;
    }

    
    if(device->unitList.count < (unitNumber+1) ){
        ioRequest->error = -1;
        return DEVICE_ERROR_UNIT_NOT_FOUND;
    }
    
    uint32_t index = 0;
    node = device->unitList.head;
    
    while(index < unitNumber){
        node = node->next;
        index +=1;
    }
    
    unit_t* unit =(unit_t*)node;
    unit->openCount += 1;
    
    if(flags == 0){
        //do nothing
    }
    

    ioRequest->unit = (unit_t*)node;
    ioRequest->error = 0;
    
    return DEVICE_NO_ERROR;
    
}


ioRequest_t* CreateIORequest(messagePort_t* replyPort,uint64_t size){
    ioRequest_t* req = (ioRequest_t*)executive->Alloc(size);
    req->message.replyPort = replyPort;
    return req;
}


void SendIO(ioRequest_t* req){
    req->device->BeginIO(req);
    
}

void DoIO(ioRequest_t* req){
    
    req->flags |= IOF_QUICK;
    req->device->BeginIO(req);
    
}



void dummyStub(void){
    //debug_write_string("Unimpelmented Function\n");
    return;
}

void InitMemory(void* startAddress, uint64_t size){
    
    executive =(executive_t*)startAddress;
    
    InitList(startAddress);
    executive_t* executive = startAddress;
    executive->memSize = size;
    

    node_t* freeblock = startAddress + sizeof(executive_t);
    freeblock->size = size - sizeof(executive_t);
    freeblock->type = MEM_TYPE_FREE;
    freeblock->nodeType = NODE_MEMORY;
    freeblock->nextContigious = NULL;
    AddHead(startAddress, freeblock);
    
    executive->quantum = 2;
    executive->elapsed = executive->quantum;
    
    
    executive->Alloc            = KAlloc;
    executive->Dealloc          = KDealloc;
    
    executive->AllocMem         = AllocMem;
    executive->FreeMem          = FreeMem;
    
    executive->InitList         = InitList;
    
    executive->AddHead          = AddHead;
    executive->AddTail          = AddTail;
    
    executive->Enqueue          = Enqueue;
    executive->EnqueueSize      = EnqueueSize;
    
    executive->FindName         = FindName;
    executive->ItemAtIndex      = ItemAtIndex;
    executive->Insert           = Insert;
    executive->Remove           = Remove;
    
    executive->RemHead          = RemHead;
    executive->RemTail          = RemTail;
    
    executive->AddLibrary       = AddLibrary;
    executive->OpenLibrary      = OpenLibrary;
    
    executive->CreatePort       = CreatePort;
    executive->DeletePort       = DeletePort;
    executive->FindPort         = FindPort;

    executive->GetMessage       = GetMessage;
    executive->PutMessage       = PutMessage;
    executive->ReplyMessage     = ReplyMessage;

    executive->AddPort          = AddPort;
    executive->RemovePort       = RemovePort;

    executive->WaitPort         = WaitPort;
    
    executive->Forbid           = dummyStub;
    executive->Permit           = dummyStub;
    
    //devices
    executive->AddDevice        = AddDevice;
    executive->OpenDevice       = OpenDevice;
    executive->SendIO           = SendIO;
    executive->DoIO             = DoIO;
    executive->CreateIORequest  = CreateIORequest;
    
    
    executive->thisTask = NULL;
    InitList(&executive->deviceList);
    InitList(&executive->libraryList);
    InitList(&executive->portList);
    InitList(&executive->taskReady);
    InitList(&executive->taskWait);
    InitList(&executive->taskSuspended);

    return;
}
