//
//  dos.h
//
//  Created by Matt Parsons on 20/11/2020.
//  Copyright © 2020 Matt Parsons. All rights reserved.
//

#ifndef dos_h
#define dos_h

#include "stdheaders.h"
#include "library.h"
#include "device.h"
#include "list.h"

typedef struct{
    node_t node;
    char* handlerName;
    uint32_t handlerNumber;
    ioRequest_t* handlerRequest;
    
    char* deviceName;
    uint32_t unitNumber;
    
}dosEntry_t;

typedef struct{
    char* fileName;
    uint64_t fileSize;
    uint64_t numberOfBlocks;
    uint64_t startBlock;
    ioRequest_t* handlerRequest;
}file_t;


typedef struct{
    library_t library;
    list_t dosList;
    void (*AddDosEntry)(dosEntry_t* entry);
    file_t* (*Open)(char* fileName, uint64_t attributes);
}dos_t;


extern dos_t dos;


void LoadDOSLibrary();

#endif /* dos_h */
