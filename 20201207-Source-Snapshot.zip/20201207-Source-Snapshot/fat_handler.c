//
//  fat_handler.c
//
//  Created by Matt Parsons on 27/11/2020.
//  Copyright © 2020 Matt Parsons. All rights reserved.
//

#include "fat_handler.h"
#include "memory.h"

#include "SystemLog.h"

fatHandler_t fatHandler;

ioRequest_t* req;

void FATInit(){
    fatHandler.device.library.node.name = "fat.handler";
    executive->InitList(&fatHandler.device.unitList);
    
    unit_t* unit = (unit_t*)executive->Alloc(sizeof(unit_t));
    executive->AddTail(&fatHandler.device.unitList,(node_t*)unit);
}

void FATOpen(library_t* lib){
    lib->openCount += 1;
}


void BeginIO(){
    
    
}

void SetHandler(dosEntry_t* entry){
    //set the underlying block device
    
    req = executive->CreateIORequest(NULL,sizeof(ioRequest_t));
    executive->OpenDevice(entry->deviceName,0,req,0);
    
   debug_write_string("FAT: ");
   debug_write_string(entry->deviceName); debug_write_string(" wank\n");
}

void LoadFATHandler(){

    fatHandler.device.library.Init  = FATInit;
    fatHandler.device.library.Open  = FATOpen;
    fatHandler.device.BeginIO       = BeginIO;
    fatHandler.SetHandler            = SetHandler;
}
