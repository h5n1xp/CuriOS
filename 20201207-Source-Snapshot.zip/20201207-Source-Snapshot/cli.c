//
//  cli.c
//
//  Created by Matt Parsons on 10/11/2020.
//  Copyright © 2020 Matt Parsons. All rights reserved.
//

#include "cli.h"

#include "string.h"
#include "list.h"
#include "memory.h"
#include "intuition.h"

#include "ata.h"
#include "fat_handler.h"
#include "dos.h"

#include "SystemLog.h"



int32_t width;
int32_t height;
int32_t x;
int32_t y;

uint32_t conCurX;
uint32_t conCurY;

intuition_t* intuibase;

uint32_t bufferIndex;


char consoleBuffer[4096];

void ConsoleClearCursor(window_t* window){

    intuibase->DrawRectangle(window,conCurX, conCurY, 8, 16, intuibase->backgroundColour);
}



void ConsoleDrawCursor(window_t* window, uint32_t x, uint32_t y){
    conCurX = (x*8)+4;
    conCurY = (y*16)+22;
    intuibase->DrawRectangle(window,conCurX, conCurY, 8, 16, intuibase->orange);
}

void ConsoleRedraw(window_t* window);


void ConsoleScroll(window_t* window){
    
    
    if(bufferIndex >= 4095){
        
        for(int i = 0 ; i< 2048;++i){
            
            consoleBuffer[i] = consoleBuffer[i+2048];
            
        }
        
        bufferIndex = 2047;
        
    }
    
    ConsoleRedraw(window);
}



void ConsolePutCharPrivate(window_t* window, char character){
    
    //Doesn't record the character placement in the console buffer
    
    ConsoleClearCursor(window);
    
    if(character=='\n'){
        ++y;
        x=0;
        
        if(y >= height){
               ConsoleScroll(window);
               //y -= 1;
           }
        
    }else if(character=='\t'){
        
        x = (x + 7) & 0xFFF8;
        
    }else{
    
        intuibase->PutChar(window,(x*8)+4,(y*16)+22,character,intuibase->white,intuibase->backgroundColour);
    
        x++;
        if(x>width){
            y++;
            
            if(y >= height){
                ConsoleScroll(window);
                //y -= 1;
            }
            
            x=0;
        }
    
    }
    ConsoleDrawCursor(window,x,y);
}

void ConsolePutChar(window_t* window, char character){
    
    
    consoleBuffer[bufferIndex++] = character;
    if(bufferIndex >= 4095){
        
        for(int i = 0 ; i < 2048;++i){
            
            consoleBuffer[i] = consoleBuffer[i+2048];
            
        }
        
        bufferIndex = 2048;
        
    }
    
    
    ConsolePutCharPrivate(window, character);

    
}

void ConsoleRedraw(window_t* window){
 
    //Count lines
    int32_t lines = 0;
    uint32_t i = 0;
    char c = 0;
    
    int32_t lineLength = 0;
    
    do{
        c = consoleBuffer[i];
        lineLength += 1;
        
        if(c =='\n'){
            lines += 1;
            lineLength = 0;
        }
        
        if(lineLength >= width){
            lines += 1;
            lineLength = 0;
        }
        
        i += 1;
    }while(i<bufferIndex);
    
    if(lines >= height){
    
        uint32_t startline = lines - height;

        lines = 0;
        i = 0;
        c = 0;
    
        uint32_t lineLength = 0;
    
        do{
            c = consoleBuffer[i];
            lineLength += 1;
        
            if(c =='\n'){
                lines += 1;
                lineLength = 0;
            }
        
            if((uint32_t)lineLength >= (uint32_t)width){
                lines += 1;
                lineLength = 0;
            }
        
            i += 1;
        }while((uint32_t)lines <= startline);
    
    }else{
        i = 0;
    }
    
    x = 0;
    y = 0;
    
    intuibase->ClearWindow(window);
    
    for(; i<bufferIndex;++i){
        ConsolePutCharPrivate(window,consoleBuffer[i]);
    }

    
    
    
}

void ConsoleWriteString(window_t* window, char* str){
    
    uint32_t size = strlen(str);
    
    for (size_t i = 0; i < size; i++){
        ConsolePutChar(window,str[i]);
    }
    
    
}

void ConsoleBackSpace(window_t* window){
    ConsoleClearCursor(window);
    x -= 1;
    bufferIndex -= 1;
    
    if(x<0){
        x = width;
        y -= 1;
    }
    ConsoleDrawCursor(window,x,y);
}


uint32_t commandBufferIndex = 0;
char commandBuffer[512];

void ConsoleSize(window_t* window){
    width = (window->w / 8) - 2;
    height = ((window->h - 22) / 16) - 1;
}




int CliEntry(void){
    
    intuibase = (intuition_t*) executive->OpenLibrary("intuition.library",0);
    
    window_t* console = intuibase->OpenWindow(NULL,0,22,intuibase->screenWidth,(intuibase->screenHeight/2)-24,WINDOW_TITLEBAR | WINDOW_DRAGGABLE | WINDOW_DEPTH_GADGET | WINDOW_RESIZABLE, "BootShell");
    console->eventPort = executive->CreatePort("Event Port");

    ConsoleSize(console);
    x = 0;
    y = 0;
    conCurX = (x*8)+4;
    conCurY = (y*16)+22;

     // This bootshell task, this should be responsible for much of the system set up
    
    ConsoleWriteString(console,"Copyright ");
    ConsolePutChar(console,169);
    ConsoleWriteString(console,"2020 Matt Parsons.\nAll rights reserved.\nRelease 0.43a\n\n");
    
    //Initilise and open DOS library
    LoadDOSLibrary();
    executive->AddLibrary((library_t*)&dos);
    executive->OpenLibrary("dos.library",0);    // never use a library without opening it first
    
    //Add a FAT file system handler to DOS on top of the ATA device, first partition.
    node_t* node = executive->Alloc(sizeof(dosEntry_t));
    node->name = "DH0";
    dosEntry_t* entry       = (dosEntry_t*)node;
    entry->handlerName      = "fat.handler";
    entry->handlerNumber    = 0;
    entry->deviceName       = "ata.device";
    entry->unitNumber       = 0;
    dos.AddDosEntry(entry);
    
    
    
    
    
    messagePort_t* diskPort = executive->CreatePort("Disk Port");
    ioRequest_t* req = executive->CreateIORequest(diskPort, sizeof(ioRequest_t));
    
    
    if(executive->OpenDevice("ata.device",0,req,0)){
        debug_write_string("No Hard Disk!!!\n");
    }
    
    uint8_t* buffer = executive->AllocMem(1024,0);
    
    req->command = CMD_READ;
    req->offset = 0;
    req->length = 1024;
    req->data = buffer;
    executive->SendIO(req);
    

    ConsoleWriteString(console,"First Sector of the Boot disk:\n");
    executive->WaitPort(diskPort);
    executive->GetMessage(diskPort);    //must GetMessage() to access it;
    
    for(int i = 0; i <1024; ++i){
        
        ConsolePutChar(console,buffer[i]);
        
    }
    ConsolePutChar(console,'\n');ConsolePutChar(console,'\n');
    
    req->command = CMD_READ;
    req->offset = 1024;
    req->length = 512;
    req->data = buffer;
    executive->SendIO(req);
    executive->WaitPort(diskPort);
    executive->GetMessage(diskPort);   //must GetMessage() to access it;
    
    for(int i = 0; i <512; ++i){
        
        ConsolePutChar(console,buffer[i]);
        
    }
    ConsolePutChar(console,'\n');

    
    
    
    
    
    
    
    ConsoleWriteString(console,"1> ");
    while(1){
        executive->WaitPort(console->eventPort);
    
        intuitionEvent_t* event = (intuitionEvent_t*) executive->GetMessage(console->eventPort);
    
        while(event != NULL){
        
            if(event->flags & WINDOW_EVENT_RESIZE){
                intuibase->ResizeWindow(console, console->w - event->mouseXrel, console->h - event->mouseYrel);
                ConsoleSize(console);
            }
            
            if(event->flags & WINDOW_EVENT_RESIZE_END){
                
                ConsoleRedraw(console);
                
            }
        
            if(event->flags & WINDOW_EVENT_KEYDOWN){
            

                
                    if(event->rawKey == 0xE){
                        //delete key
                        
                        if(commandBufferIndex > 0){
                            commandBufferIndex -=1;
                            ConsoleBackSpace(console);
                        }
                        
                    }else if(event->rawKey == 0x1C){
                        // enter key
                        commandBuffer[commandBufferIndex]= 0;
                        if(commandBufferIndex>0){
                            ConsolePutChar(console,'\n');
                            ConsoleWriteString(console,"Unknown command ");
                            ConsoleWriteString(console,commandBuffer);
                        }
                        
                        commandBufferIndex  = 0;
                        ConsoleWriteString(console,"\n1> ");
                    }else if(event->rawKey == 0x48){
                        //up cursor
                    }else{
                        if(commandBufferIndex < 255){
                            commandBuffer[commandBufferIndex] = event->scancode;
                            commandBufferIndex += 1;
                            ConsolePutChar(console, event->scancode);
                        }
                    }
        
                
            }
        
            //executive->Dealloc((node_t*)event);
            executive->ReplyMessage((message_t*)event); // Always reply a message as soon as possible
            event = (intuitionEvent_t*) executive->GetMessage(console->eventPort);
        }
    
    }
}
