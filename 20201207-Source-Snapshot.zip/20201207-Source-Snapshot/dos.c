//
//  dos.c
//
//  Created by Matt Parsons on 20/11/2020.
//  Copyright © 2020 Matt Parsons. All rights reserved.
//

#include "dos.h"
#include "memory.h"

#include "ata.h"
#include "fat_handler.h"
#include "string.h"

#include "SystemLog.h"

dos_t dos;




file_t* Open(char* fileName, uint64_t attributes){
    
    return NULL;
    
}

void InitDOS(library_t* library){
    //called by AddLibrary(), does the library set up.
    
    InitList(&dos.dosList);
    library->node.name = "dos.library";
 
    //The DOS.library will need to access the disks
    //setup the ata device
    LoadATADevice();
    executive->AddDevice((device_t*)&ata);
    
    //The boot disk will be FAT32
    LoadFATHandler();
    executive->AddDevice((device_t*)&fatHandler);
    
}

void OpenLib(library_t* lib){
    //dos.library.openCount +=1;
    lib->openCount +=1;
    
    //initilise the DOS Message port of the calling task
    task_t* task  = executive->thisTask;
    task->dosPort = executive->CreatePort(NULL);
    
}


void CloseLib(library_t* lib){
    //dos.library.openCount -=1;
    lib->openCount -=1;
    
    //remove DOS message port
    task_t* task  = executive->thisTask;
    executive->DeletePort((messagePort_t*)task->dosPort);
}

void AddDosEntry(dosEntry_t* entry){

    //need to setup the iorequests etc...
    
    AddTail(&dos.dosList,(node_t*) entry);
    
    entry->handlerRequest = executive->CreateIORequest(NULL,sizeof(ioRequest_t));
    executive->OpenDevice(entry->handlerName,0,entry->handlerRequest,0);
    
    fatHandler_t* handler = (fatHandler_t*)entry->handlerRequest->device;
    handler->SetHandler(entry);
    
    
    
    
    
    
    node_t* node = (node_t*)entry->handlerRequest->device;
    debug_write_string( node->name );debug_write_string("\n");
    
}


void LoadDOSLibrary(){
    
    dos.library.Init    = InitDOS;
    dos.library.Open    = OpenLib;
    dos.library.Close   = CloseLib;
    dos.AddDosEntry     = AddDosEntry;
    
}
