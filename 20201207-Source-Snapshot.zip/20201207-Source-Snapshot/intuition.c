//
//  intuition.c
//
//  Created by Matt Parsons on 26/10/2020.
//  Copyright © 2020 Matt Parsons. All rights reserved.
//

#include "intuition.h"
#include "memory.h"
#include "string.h"
#include "input.h"

#include "SystemLog.h"

uint8_t oldMousePointer[] ={
1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 3, 3, 3, 3, 3, 3, 3, 3, 2, 2, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 3, 3, 3, 3, 3, 3, 3, 3, 2, 2, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 3, 3, 3, 3, 3, 3, 2, 2, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 3, 3, 3, 3, 3, 3, 2, 2, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 3, 3, 3, 3, 3, 3, 3, 3, 2, 2, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 3, 3, 3, 3, 3, 3, 3, 3, 2, 2, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 3, 3, 3, 3, 1, 1, 3, 3, 3, 3, 2, 2, 1, 1, 0, 0, 0, 0, 0, 0, 1, 1, 3, 3, 3, 3, 1, 1, 3, 3, 3, 3, 2, 2, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 1, 1, 0, 0, 1, 1, 3, 3, 3, 3, 2, 2, 1, 1, 0, 0, 0, 0, 0, 0, 1, 1, 1, 1, 0, 0, 1, 1, 3, 3, 3, 3, 2, 2, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 3, 3, 3, 3, 2, 2, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 3, 3, 3, 3, 2, 2, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 3, 3, 3, 3, 2, 2, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 3, 3, 3, 3, 2, 2, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 3, 3, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 3, 3, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 0, 0, 0, 0};

uint8_t newMousePointer[] ={
3,3,2,2,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,
3,3,2,2,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,
1,1,3,3,2,2,2,2,0,0,0,0,0,0,0,0,0,0,0,0,0,0,
1,1,3,3,2,2,2,2,0,0,0,0,0,0,0,0,0,0,0,0,0,0,
0,0,1,1,3,3,3,3,2,2,2,2,0,0,0,0,0,0,0,0,0,0,
0,0,1,1,3,3,3,3,2,2,2,2,0,0,0,0,0,0,0,0,0,0,
0,0,1,1,3,3,3,3,3,3,3,3,2,2,2,2,0,0,0,0,0,0,
0,0,1,1,3,3,3,3,3,3,3,3,2,2,2,2,0,0,0,0,0,0,
0,0,0,0,1,1,3,3,3,3,3,3,3,3,3,3,2,2,2,2,0,0,
0,0,0,0,1,1,3,3,3,3,3,3,3,3,3,3,2,2,2,2,0,0,
0,0,0,0,1,1,3,3,3,3,3,3,3,3,3,3,3,3,3,3,0,0,
0,0,0,0,1,1,3,3,3,3,3,3,3,3,3,3,3,3,3,3,0,0,
0,0,0,0,0,0,1,1,3,3,3,3,3,3,2,2,0,0,0,0,0,0,
0,0,0,0,0,0,1,1,3,3,3,3,3,3,2,2,0,0,0,0,0,0,
0,0,0,0,0,0,1,1,3,3,3,3,1,1,3,3,2,2,0,0,0,0,
0,0,0,0,0,0,1,1,3,3,3,3,1,1,3,3,2,2,0,0,0,0,
0,0,0,0,0,0,0,0,1,1,3,3,0,0,1,1,3,3,2,2,0,0,
0,0,0,0,0,0,0,0,1,1,3,3,0,0,1,1,3,3,2,2,0,0,
0,0,0,0,0,0,0,0,1,1,3,3,0,0,0,0,1,1,3,3,2,2,
0,0,0,0,0,0,0,0,1,1,3,3,0,0,0,0,1,1,3,3,2,2,
0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1,1,3,3,
0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1,1,3,3};
    
uint8_t macMousePointer[] ={
4,4,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,
4,1,4,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,
4,1,1,4,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,
4,1,1,1,4,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,
4,1,1,1,1,4,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,
4,1,1,1,1,1,4,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,
4,1,1,1,1,1,1,4,0,0,0,0,0,0,0,0,0,0,0,0,0,0,
4,1,1,1,1,1,1,1,4,0,0,0,0,0,0,0,0,0,0,0,0,0,
4,1,1,1,1,1,1,1,1,4,0,0,0,0,0,0,0,0,0,0,0,0,
4,1,1,1,1,1,4,4,4,4,4,0,0,0,0,0,0,0,0,0,0,0,
4,1,1,4,1,1,4,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,
4,1,4,0,4,1,1,4,0,0,0,0,0,0,0,0,0,0,0,0,0,0,
4,4,0,0,4,1,1,4,0,0,0,0,0,0,0,0,0,0,0,0,0,0,
4,0,0,0,0,4,1,1,4,0,0,0,0,0,0,0,0,0,0,0,0,0,
0,0,0,0,0,4,1,1,4,0,0,0,0,0,0,0,0,0,0,0,0,0,
0,0,0,0,0,0,4,4,4,0,0,0,0,0,0,0,0,0,0,0,0,0,
0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,
0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,
0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,
0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,
0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,
0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0};
    
intuition_t intuition;

list_t windowList;
//window_t* focused;
window_t* mouseOver;
uint32_t mouseOverX;
uint32_t mouseOverY;

window_t* dragging = NULL;
window_t* resizing = NULL;

char* screenTitle;

bool mouseVisible = false;
bool leftMouseHeld = false;

volatile int32_t mouseX=0;
volatile int32_t mouseY=0;
int32_t mouseXold = 0;
int32_t mouseYold = 0;


void drawWindowDecoration(window_t*); //forward declare this function.

uint64_t doubleClickTime = 500;

 
void updateMouse(){
    
    if(inputStruct.rawMouse[3] == 0){
        return;
    }
    

    
    mouseXold = mouseX;
    mouseYold = mouseY;
    
    mouseX += inputStruct.rawMouse[1];
    mouseY -= inputStruct.rawMouse[2];  // y is negative for some reason
    
    
    inputStruct.rawMouse[1] = 0;
    inputStruct.rawMouse[2] = 0;
    inputStruct.rawMouse[3] = 0;
    
    if(mouseX < 0){
        mouseX = 0;
    }
    
    if((uint32_t)mouseX > (graphics.frameBuffer.width-1)){
        mouseX = graphics.frameBuffer.width-1;
    }
    

    if(mouseY < 0){
        mouseY = 0;
    }
    
    if((uint32_t)mouseY > (graphics.frameBuffer.height-1)){
        mouseY = graphics.frameBuffer.height-1;
    }

    
    
    //left mouse released
    if(leftMouseHeld == true && ( (inputStruct.rawMouse[0] & 1) == 0)){
        leftMouseHeld = false;
        dragging = NULL;
        
        if(resizing != NULL){
            if(resizing->eventPort != NULL){
                intuitionEvent_t* event = (intuitionEvent_t*) executive->Alloc(sizeof(intuitionEvent_t));
                event->message.replyPort = NULL;
                event->flags = WINDOW_EVENT_RESIZE_END;
                event->window = resizing;
                event->mouseX = mouseX;
                event->mouseY = mouseY;
                event->mouseXrel = mouseXold - mouseX;
                event->mouseYrel = mouseYold - mouseY;
                executive->PutMessage(resizing->eventPort,(message_t*)event);
            }
            resizing = NULL;
        }
        return;
    }
    
    
    
    if(dragging != NULL){
        
        MoveWindow(dragging,mouseX - dragging->mouseX, mouseY - dragging->mouseY);
        return;
    }
    
    
    
    if(resizing != NULL){
        
        if(mouseX == mouseXold && mouseY == mouseYold){            
            return;
        }
        
        
        if(resizing->eventPort != NULL){
            intuitionEvent_t* event = (intuitionEvent_t*) executive->Alloc(sizeof(intuitionEvent_t));
            event->message.replyPort = NULL;
            event->flags = WINDOW_EVENT_RESIZE;
            event->window = resizing;
            event->mouseX = mouseX;
            event->mouseY = mouseY;
            event->mouseXrel = mouseXold - mouseX;
            event->mouseYrel = mouseYold - mouseY;
            executive->PutMessage(resizing->eventPort,(message_t*)event);
        }
        return;

    }
    
    
    

    
    
    
    if(leftMouseHeld == false){
        mouseOver = NULL;
        
        node_t* pred = windowList.pred;
        
        
        do{
            window_t* window = (window_t*)pred;
            
            window->mouseX = mouseX - window->x;
            window->mouseY = mouseY - window->y;
            
            if((uint32_t)mouseX>window->x && (uint32_t)mouseX < window->x + window->w){
                if((uint32_t)mouseY>window->y && (uint32_t)mouseY < window->y + window->h){
                
                    mouseOver = window;
                
                    if( (inputStruct.rawMouse[0]&1) && leftMouseHeld == false){
                        
                        //Process double click
                        if(window->doubleClick == 0){
                            
                            window->doubleClick = executive->ticks + doubleClickTime;
                            
                        }else if(executive->ticks < window->doubleClick){
                            
                            WindowToFront(window);
                            window->doubleClick = 0;
                        }else{
                            window->doubleClick = 0;
                        }
                        
                        
                        //Ressizable?
                        if(window->flags & WINDOW_RESIZABLE){
                            
                            if((uint32_t)mouseX > (window->x + window->w - 17) && (uint32_t)mouseY > (window->y + window->h - 18) ){
                                
                                if((uint32_t)mouseX < (window->x + window->w ) && (uint32_t)mouseY < (window->y + window->h) ){
                                  resizing = window;
                                    window->doubleClick = 0;
                                }
                            }
                            
                        }
                    
                        
                        //is there a title bar?
                        if( window->flags & WINDOW_TITLEBAR){
                            
                            //is mouse in the title area
                            if(mouseY - window->y < 20){
                    
                                //check for depth gadget
                                if( (window->flags & WINDOW_DEPTH_GADGET) && ((uint32_t)mouseX > (window->x+window->w)-28) ){
                                    window->doubleClick = 0;

                                    if(window == (window_t*)windowList.pred){
                                        WindowToBack(window);
                                    }else{
                                        WindowToFront(window);
                                    }
                                    
                                
                                // If draggable, then drag
                                } else if(window->flags & WINDOW_DRAGGABLE){
                                    
                                    dragging = window;
                                }
                            }
                        }
                            
                        Focus(window);
                        
                    }
                
                    break;
                
                }
            }
        
            pred = pred->prev;
        }while(pred->prev != NULL);
        
        if( (inputStruct.rawMouse[0] & 1) == 1){
            leftMouseHeld = true;
        }
    }

    
}


//*************** Assembly highspeed copy
inline void movsd(void* dst, const void* src, size_t size){
    asm volatile("rep movsl" : "+D"(dst), "+S"(src), "+c"(size) : : "memory");
}

uint32_t mouseBuffer[22*22];

void clearMouse(){
    
    uint32_t index = 0;
    uint32_t* p = graphics.frameBuffer.buffer;
    
    /*
    uint32_t w = (uint32_t)mouseX + 22;
    uint32_t h = (uint32_t)mouseY + 22;
    
    if(w >= graphics.frameBuffer.width){w = graphics.frameBuffer.width;}
    if(h >= graphics.frameBuffer.height){h = graphics.frameBuffer.height;}
    
    for(uint32_t y = (uint32_t)mouseY;y < h;++y){
        
     
        for(uint32_t x = (uint32_t)mouseX; x < w;++x){
            
            //if(x<graphics.frameBuffer.width && y<graphics.frameBuffer.height){
                p[(y * graphics.frameBuffer.width) + x] =  mouseBuffer[index];
            //}
            index += 1;
        }
    

        
        
    }
    */

    uint32_t w = 22;
    uint32_t h = 22;
    
    
    if(mouseX + w >= graphics.frameBuffer.width){w = graphics.frameBuffer.width - mouseX;}
    if(mouseY + h >= graphics.frameBuffer.height){h = graphics.frameBuffer.height - mouseY;}
    
    for(uint32_t y = 0; y<h;++y){
        
        movsd(&p[((mouseY+y)*graphics.frameBuffer.width)+mouseX],&mouseBuffer[index],w);
        
        index += 22;
        
    }
    
    
    
}

void drawMouse(){
    
    uint32_t index = 0;
    uint32_t* p = graphics.frameBuffer.buffer;
    
    

    
    
    
    //save background
    /*
    for(uint32_t y = (uint32_t)mouseY;y < h;++y){
        for(uint32_t x = (uint32_t)mouseX; x < w;++x){
            
                mouseBuffer[index] = p[(y * graphics.frameBuffer.width) + x];
            
            index += 1;
        }
    }
    */
    
    uint32_t w = 22;
    uint32_t h = 22;
    
    
    if(mouseX + w >= graphics.frameBuffer.width){w = graphics.frameBuffer.width - mouseX;}
    if(mouseY + h >= graphics.frameBuffer.height){h = graphics.frameBuffer.height - mouseY;}
    
    for(uint32_t y = 0; y<h;++y){
        
        movsd(&mouseBuffer[index],&p[((mouseY+y)*graphics.frameBuffer.width)+mouseX],w);
        
        index += 22;
        
    }
    
    
    
    //draw pointer
    w = (uint32_t)mouseX + 22;
    h = (uint32_t)mouseY + 22;
    
    if(w >= graphics.frameBuffer.width){w = graphics.frameBuffer.width;}
    if(h >= graphics.frameBuffer.height){h = graphics.frameBuffer.height;}
    
    index = 0;
    for(uint32_t y = (uint32_t)mouseY;y < (uint32_t)mouseY+22;++y){
        for(uint32_t x = (uint32_t)mouseX; x < (uint32_t)mouseX+22;++x){
            
            if(x<graphics.frameBuffer.width && y<graphics.frameBuffer.height){
                if(intuition.mouseImage[index] == 1){
                    p[(y * graphics.frameBuffer.width) + x] =  0;   //black
                }
            
                if(intuition.mouseImage[index] == 2){
                    p[(y * graphics.frameBuffer.width) + x] =  intuition.grey;
                }
            
                if(intuition.mouseImage[index] == 3){
                    p[(y * graphics.frameBuffer.width) + x] =  intuition.red;
                }
                
                if(intuition.mouseImage[index] == 4){
                    p[(y * graphics.frameBuffer.width) + x] =  intuition.white;
                }
                
            }
            index += 1;
        }
    }
    
}

void RedrawWindow(window_t* window){
    
    window->needsRedraw = true;
    
    Lock(&window->clipRectsLock);
    for(uint32_t i = 0;i<window->clipRects;++i){
        window->clipRect[i].needsUpdate = true;
    }
    FreeLock(&window->clipRectsLock);
    
    window->autoRefeshCountdown = 60;
    
}

void drawTitleBar(){
    
    if(inputStruct.screenTitle == NULL){
        return;
    }
    
    if(screenTitle == NULL){
        screenTitle = "System Screen";
    }
    
    graphics.DrawRect(inputStruct.screenTitle->bitmap, 0,0,graphics.frameBuffer.width,20,intuition.white);
    graphics.RenderString(inputStruct.screenTitle->bitmap, 4,2,screenTitle,intuition.blue,intuition.white);
    RedrawWindow(inputStruct.screenTitle);
}


void RedrawBlitRects(window_t* window){
 
    Lock(&window->clipRectsLock);
    
    for(uint32_t i = 0; i<window->clipRects; ++i){
        if(window->clipRect[i].isVisible){
            
            if(window->clipRect[i].needsUpdate == true){
                
                //graphics.DrawRect(&graphics.frameBuffer, window->x+window->clipRect[i].x,window-> y+ window->clipRect[i].y, window->clipRect[i].w,  window->clipRect[i].h, intuition.black);
                //graphics.DrawRect(&graphics.frameBuffer, window->x+window->clipRect[i].x+1,window-> y+ window->clipRect[i].y+1, window->clipRect[i].w-2,  window->clipRect[i].h-2, intuition.orange);
                
                graphics.BlitRect(window->bitmap, window->clipRect[i].x, window->clipRect[i].y, window->clipRect[i].w, window->clipRect[i].h, &graphics.frameBuffer, window->x+window->clipRect[i].x, window->y+window->clipRect[i].y);
                window->clipRect[i].needsUpdate = false;
            }
        }
    }
    FreeLock(&window->clipRectsLock);
    
    window->needsRedraw = false;
}

void updateLayers(window_t*); //forward declaration...

void IntuitionUpdate(void){
    clearMouse();
    updateMouse();
    drawTitleBar();
    
    //Resizing hack, to display window content when mouse stops moving
    
    if(resizing != NULL){
        if(resizing->eventPort != NULL){
            intuitionEvent_t* event = (intuitionEvent_t*) executive->Alloc(sizeof(intuitionEvent_t));
            event->flags = WINDOW_EVENT_RESIZE_END;
            event->message.replyPort = NULL;
            //event->window = resizing;
            //event->mouseX = mouseX;
            //event->mouseY = mouseY;
            //event->mouseXrel = mouseXold - mouseX;
            //event->mouseYrel = mouseYold - mouseY;
            executive->PutMessage(resizing->eventPort,(message_t*)event);
            intuition.needsUpdate = true;
        }
    }
    
    
    if(windowList.count == 0){
        return;
    }

    
    if(intuition.needsUpdate){
        updateLayers(NULL);
        intuition.needsUpdate = false;
    }
   
    
    /* //This is the proper way to draw the window rects, front to back, but the clipping code make and error so which needs to be fixed
    node_t* node = windowList.pred;
    
    do{
        window_t* window =(window_t*)node;
        
        if(window->needsRedraw == true){
            RedrawBlitRects(window);
        }else{
            
            //each window is redrawn after one second
            window->autoRefeshCountdown -=1;
            
            if(window->autoRefeshCountdown <0){
                RedrawWindow(window);
            }
        }
        
        
        node = node->prev;
    }while(node->prev !=NULL);
    */
    
    
    //Below is the wrong way to draw the cliprects as it covers up that one of the clip rect condiditons isn't calculated properly.
    //executive->Forbid();
    node_t* node = windowList.head;

    do{
        window_t* window =(window_t*)node;
        
        if(window->needsRedraw == true){
            RedrawBlitRects(window);
        }else{
            
            //each window is redrawn after one second
            window->autoRefeshCountdown -=1;
            
            if(window->autoRefeshCountdown <0){
                RedrawWindow(window);
            }
        }
        
        
        node = node->next;
    }while(node->next !=NULL);
    //executive->Permit();
    
    drawMouse();
}

void DrawCloseGadget(window_t* window){
    
    graphics.DrawRect(window->bitmap,4,0,24,20,intuition.blue);
    graphics.DrawRect(window->bitmap,6,0,20,20,intuition.white);
    graphics.DrawRect(window->bitmap,8,2,16,16,intuition.blue);
    graphics.DrawRect(window->bitmap,10,4,12,12,intuition.white);
    graphics.DrawRect(window->bitmap,14,8,4,4,intuition.black);
}

void DrawDepthGadget(window_t* window){
    
    uint32_t x = window->w - 29;
    
    graphics.DrawRect(window->bitmap,x+2,0,24,20,intuition.blue);
    graphics.DrawRect(window->bitmap,x+4,0,20,20,intuition.white);
    
    graphics.DrawRect(window->bitmap,x+6,2,12,12,intuition.black);
    graphics.DrawRect(window->bitmap,x+10,6,12,12,intuition.blue);
    graphics.DrawRect(window->bitmap,x+12,8,8,8,intuition.white);
    
}

void DrawSizeGadget(window_t* window){
    graphics.DrawRect(window->bitmap,window->w - 17, window->h - 18,17,18,intuition.white);
    graphics.DrawRect(window->bitmap,window->w - 17+3, window->h - 18 +3,6,6,intuition.blue);
    
    graphics.DrawRect(window->bitmap,window->w - 17+7, window->h - (12),8,10,intuition.blue);
    
    graphics.DrawRect(window->bitmap,window->w - 12, window->h - 13,2,2,intuition.white);
    graphics.DrawRect(window->bitmap,window->w - 8, window->h - 10,4,6,intuition.white);
}


void drawWindowTitleBar(window_t* window){

    DrawRectangle(window,0,0,window->w,20,intuition.white);
    
    //text start and stop
    uint32_t s = (uint32_t)strlen(window->node.name)*8;
    uint32_t l = 5;
    
    if(window->flags & WINDOW_CLOSE_GADGET){
        DrawCloseGadget(window);
        l = 31;
    }
    

    graphics.RenderString(window->bitmap,l,2,window->node.name,intuition.blue,intuition.white);
    
    uint32_t dragBarX2 = 5 + l;
    
    if(window->flags & WINDOW_DEPTH_GADGET){
        dragBarX2 += 28;
        DrawDepthGadget(window);
    }
    
    if(window->flags & WINDOW_DRAGGABLE){
        DrawRectangle(window,l+3+s,4,(window->w - s)-dragBarX2,4,intuition.blue);
        DrawRectangle(window,l+3+s,12,(window->w - s)-dragBarX2,4,intuition.blue);
    }
    
    

    
    
    
    if(window->focused == false){
        int v=0;
        for(uint32_t cx=l; cx<window->w-dragBarX2+6+l; cx++){
            for(uint32_t cy=0; cy<20; cy++){
                
                if(cx<window->w){
                    if(v<3){
                        graphics.PutPixel(window->bitmap,cx,cy,intuition.white);
                    }
                }
                
                v += 1;
                if(v>5){v=0;};
            }
            
        }
    }
    

    
    
}

void drawWindowBorder(window_t* window){
    
    

    
    if(!(window->flags & WINDOW_BORDERLESS)){
        
        graphics.DrawRect(window->bitmap,0,0,window->w,2,intuition.white);
        graphics.DrawRect(window->bitmap,0,0,2,window->h,intuition.white);

    
        graphics.DrawRect(window->bitmap,0,window->h - 2,window->w-2,2,intuition.white);
        graphics.DrawRect(window->bitmap,window->w - 2,0,2,window->h,intuition.white);
    }
    

    
}

void GimmeZeroZero(window_t* window){
    
    if(window->flags & WINDOW_BORDERLESS){
        window->innerX = 0;
        window->innerY = 0;
        window->innerW = window->w;
        window->innerH = window->h;
    }else{
        window->innerX = 2;
        window->innerY = 2;
        window->innerW = window->w-4;
        window->innerH = window->h-4;
        
        if(window->flags & WINDOW_TITLEBAR){
            window->innerY = 20;
        }
 
        if(window->flags & WINDOW_RESIZABLE){
            window->innerW = window->w-18;
            window->innerH = window->h-18;
        }
        
    }
    

    
}

void drawWindowDecoration(window_t* window){
    
    drawWindowBorder(window);
    
    if(window->flags & WINDOW_TITLEBAR){
        drawWindowTitleBar(window);
    }
    
    if(window->flags & WINDOW_RESIZABLE){
        DrawSizeGadget(window);
    }
    

}

void Focus(window_t* window){
    
    if(inputStruct.focused == window){
        return;
    }
    
    if(inputStruct.focused != NULL){
        
        inputStruct.focused->focused = false;
        
        if(inputStruct.focused->flags & WINDOW_TITLEBAR){
            drawWindowTitleBar(inputStruct.focused);
        }
        
    }
    
    inputStruct.focused = window;
    window->focused = true;
    screenTitle = window->screenTitle;
    
    if(inputStruct.focused->flags & WINDOW_TITLEBAR){
        drawWindowTitleBar(inputStruct.focused);
    }
}


void SetScreenTitle(window_t* window,char* title){
    window->screenTitle = title;
}

//***********************************************



void calculateBlitRects(window_t* window){

    window->needsRedraw = true;
    node_t* winNode = (node_t*)window;
    
uint32_t sX1 = window->x;
uint32_t sY1 = window->y;
uint32_t sX2 = window->x+window->w;
uint32_t sY2 = window->y+window->h;
if(sX2 > graphics.frameBuffer.width){sX2=graphics.frameBuffer.width;}
if(sY2 > graphics.frameBuffer.height){sY2=graphics.frameBuffer.height;}
    
Lock(&window->clipRectsLock);
window->clipRect[0].isVisible=true;
window->clipRect[0].x = 0;
window->clipRect[0].y = 0;
window->clipRect[0].w = window->w;
window->clipRect[0].h = window->h;
window->clipRects = 1;
    
    //if there are no wondows above then exit
    node_t* node = window->node.next;
    if(node->next== NULL){
        window->clipRect[0].isVisible=true;
        FreeLock(&window->clipRectsLock);
        return;
    }
    
        node = windowList.pred;
    
         while (node != winNode) {
             
             window_t* above = (window_t*)node;
          
             uint32_t winX1 = above->x;
             uint32_t winY1 = above->y;
             uint32_t winX2 = above->x + above->w;
             uint32_t winY2 = above->y + above->h;
             if(winX2 > graphics.frameBuffer.width){winX2=graphics.frameBuffer.width;}
             if(winY2 > graphics.frameBuffer.height){winY2=graphics.frameBuffer.height;}
             
          
             //if window is totally covered stop processing
             if( (winX1 <= sX1) && winY1 <= sY1 && winX2 >= sX2 && winY2 >= sY2){
                 window->clipRects = 0;
                 window->clipRect[0].isVisible = false;
                 window->clipRect[0].needsUpdate = false;
                 
                 FreeLock(&window->clipRectsLock);
                 return;
             }
             
                 
             uint32_t clipCount = window->clipRects;
             for(uint32_t i=0;i<clipCount;++i){
             
                 uint32_t clipX1 = window->clipRect[i].x + window->x;
                 uint32_t clipY1 = window->clipRect[i].y + window->y;
                 uint32_t clipX2 = clipX1 + window->clipRect[i].w;
                 uint32_t clipY2 = clipY1 + window->clipRect[i].h;
                 if(clipX2 > graphics.frameBuffer.width){clipX2=graphics.frameBuffer.width;}
                 if(clipY2 > graphics.frameBuffer.height){clipY2=graphics.frameBuffer.height;}
                
                 //check the clip is completely covered
                 if( (winX1 <= clipX1) && winY1 <= clipY1 && winX2 >= clipX2 && winY2 >= clipY2){
                     window->clipRect[i].isVisible = false;
                     window->clipRect[i].needsUpdate = false;

                 }else if (clipX1 < winX2 && clipX2 > winX1 && clipY1 < winY2 && clipY2 > winY1){
                        int32_t c = -1;
                        
                        if(winY1>clipY1){
                            //new visible rect to the top
                           
                            if(c==-1){
                                c = i;
                            }else{
                                c =  window->clipRects;
                                window->clipRects +=1;
                            }
                            
                            window->clipRect[c].isVisible = true;
                            window->clipRect[c].needsUpdate = true;
                            window->clipRect[c].x = clipX1 - sX1;
                            window->clipRect[c].w = clipX2 - clipX1;
                            window->clipRect[c].y = clipY1 - sY1;
                            window->clipRect[c].h = winY1 - clipY1;
                
                        }
                        
                        if(winY2<clipY2){
                            //new visible rect to the bottom
                            
                            if(c==-1){
                                c = i;
                            }else{
                                c =  window->clipRects;
                                window->clipRects +=1;
                            }
                            
                            window->clipRect[c].isVisible = true;
                            window->clipRect[c].needsUpdate = true;
                            window->clipRect[c].x = clipX1 - sX1;
                            window->clipRect[c].w = clipX2 - clipX1;
                            window->clipRect[c].y = winY2 - sY1;
                            window->clipRect[c].h = clipY2 - winY2;
                    
                        }
                        
                        if(winX1>clipX1){
                            //new visible rect to the left
                       
                            
                          
                            if(c==-1){
                                c = i;
                            }else{
                                c =  window->clipRects;
                                window->clipRects +=1;
                            }
                            
                            window->clipRect[c].isVisible = true;
                            window->clipRect[c].needsUpdate = true;
                            window->clipRect[c].x = clipX1-sX1;
                            window->clipRect[c].w = winX1 - clipX1;
                        
                            
                            if(winY1<=clipY1){
                                window->clipRect[c].y = (clipY1 - sY1);
                                
                                if(winY2 >= clipY2){
                                    window->clipRect[c].h = clipY2 - clipY1;
                                }else{
                                    window->clipRect[c].h = winY2 - clipY1;
                                }
                            }else{
                                window->clipRect[c].y = (winY1 - sY1);
                                
                                
                                
                                if(winY2 >= clipY2){
                                    window->clipRect[c].h = clipY2 - winY1;
                                }else{
                                    window->clipRect[c].h = winY2 - winY1;
                                }
                
                            }
                            
                            
     
                        }
                        
                        if(winX2<clipX2){
                                //new visible rect to the right
                            
                           
                                if(c==-1){
                                    c = i;
                                }else{
                                    c =  window->clipRects;
                                    window->clipRects +=1;
                                }
                                
                                
                               window->clipRect[c].isVisible = true;
                               window->clipRect[c].needsUpdate = true;
                               window->clipRect[c].x = winX2 - sX1;
                               window->clipRect[c].w = clipX2 - winX2;
                                
                            
                        
                            if(winY1<=clipY1){
                                window->clipRect[c].y = (clipY1 - sY1);
                                
                                if(winY2 >= clipY2){
                                    window->clipRect[c].h = clipY2 - clipY1;
                                }else{
                                    window->clipRect[c].h = winY2 - clipY1;
                                }
                            }else{
                                window->clipRect[c].y = (winY1 - sY1);
                                
                                
                                
                                if(winY2 >= clipY2){
                                    window->clipRect[c].h = clipY2 - winY1;
                                }else{
                                    window->clipRect[c].h = winY2 - winY1;
                                }
                                
                            }
                            
                                 
                            
                        }
                        
                        if(c==-1){
                            window->clipRect[i].isVisible = false;
                            window->clipRect[i].needsUpdate = false;
                        }
                        
                        
                    }
                 
                 
             }
             
             node = node->prev;
         }
    
    FreeLock(&window->clipRectsLock);
}













void updateLayers(window_t* window){
    
    //if window = NULL, update all layers
    
    /*
    node_t* winNode = (node_t*) window;
    
    node_t* node = windowList.head;
    calculateBlitRects((window_t*)node);
    
    if(node == winNode){
        return;
    }
    
    do{
        node = node->next;
        window = (window_t*)node;
        calculateBlitRects(window);
    }while(node != winNode);
    */
    
    
    //Simply Update all layers
    node_t* node = windowList.pred;
    
    do{
        window = (window_t*)node;
        calculateBlitRects(window);
        node = node->prev;
    }while(node->prev != NULL);
  
    
    
    
}


void ResizeWindow(window_t* window, uint32_t w, uint32_t h){
    

    
    
    
    uint32_t X1 = window->x;
    uint32_t Y1 = window->y;
    
    
    
    
    if(w < window->minWidth){
        
        w = window->minWidth;
        
        if(window->w == window->minWidth && window->h == window->minHeight){

            return;
        }
        
        // mouseX = mouseXold;
 
    }
    
    
    if(h < window->minHeight){
        
        h = window->minHeight;
        
        if(window->w == window->minWidth && window->h == window->minHeight){
            return;
        }
        
        // mouseY = mouseYold;

    }
    
    
    if(w > window->maxWidth){
        w = window->maxWidth;
    }
    
    if(h > window->maxHeight){
        h = window->maxHeight;
    }
    

    


    bitmap_t* bm = graphics.NewBitmap(w, h);
    bitmap_t* old = window->bitmap;
    
    if(bm==NULL){
        return;
    }

    
    
    
    executive->Forbid();
    window->needsRedraw = false;
    window->w = w;
    window->h = h;
    GimmeZeroZero(window);
    window->bitmap = bm;
    
    // Erase window from screen
    clearMouse();
    for(uint32_t i=0;i<window->clipRects;++i){
        
        if(window->clipRect[i].isVisible){
            graphics.DrawRect(&graphics.frameBuffer,X1 + window->clipRect[i].x , Y1 + window->clipRect[i].y , window->clipRect[i].w, window->clipRect[i].h, intuition.backgroundColour);
        }
    }
    
    
    graphics.ClearBitmap(window->bitmap,intuition.backgroundColour);

    //executive->Dealloc((node_t*)old);
    graphics.FreeBitmap(old);
    
    drawMouse();
    
    executive->Permit();
    //debug_write_hex((uint32_t)bm);debug_write_string(" bitmap address\n");
    
 
    drawWindowDecoration(window);
    intuition.needsUpdate = true;
    RedrawWindow(window);
}



void MoveWindow(window_t* window,int32_t x, int32_t y){
    
    
    //No off screen moving at the moment, to match original AmigaOS 1.3 behaviour
    if(x+window->w > graphics.frameBuffer.width){
        x = graphics.frameBuffer.width - window->w;
    }
    if(y+window->h > graphics.frameBuffer.height){
        y = graphics.frameBuffer.height - window->h;
    }
    
    
    
    
    if(x<0){
        x=0;
    }
    
    if(y<0){
        y=0;
    }
    
    
    //if the window hasn't moved... don't update.
    if((uint32_t)x==window->x && (uint32_t)y==window->y){
        return;
    }
    
    uint32_t X1 = window->x;
    uint32_t Y1 = window->y;
    
    
   // Erase window from screen
    for(uint32_t i=0;i<window->clipRects;++i){
        
        if(window->clipRect[i].isVisible){
            graphics.DrawRect(&graphics.frameBuffer,X1 + window->clipRect[i].x , Y1 + window->clipRect[i].y , window->clipRect[i].w, window->clipRect[i].h, intuition.backgroundColour);
        }
    }
    
    
    window->x = x;
    window->y = y;
    
    //updateLayers(window);
    intuition.needsUpdate = true;
    RedrawWindow(window);
}


void WindowToBack(window_t* window){
    window->node.priority = 1;
    Remove(&windowList,(node_t*)window);
    Enqueue(&windowList, (node_t*)window);
    window->node.priority = 0;
    intuition.needsUpdate = true;
    //updateLayers(window);
    RedrawWindow(window);
}

void WindowToFront(window_t* window){
    window->node.priority = -1;
    Remove(&windowList,(node_t*)window);
    Enqueue(&windowList, (node_t*)window);
    window->node.priority = 0;
    intuition.needsUpdate = true;
    //updateLayers(window);
    RedrawWindow(window);
    
}

void PriorityOrderPrivate(window_t* window){
    Remove(&windowList,(node_t*)window);
    Enqueue(&windowList, (node_t*)window);
    //intuition.needsUpdate = true;
    updateLayers(window);
    RedrawWindow(window);
}

void ClearWindow(window_t* window){
    uint32_t* p = window->bitmap->buffer;
    uint32_t i = window->bitmap->width * window->bitmap->height;
    do{
        i -= 1;
        p[i] = intuition.backgroundColour;
    }while(i > 0);
    drawWindowDecoration(window);
}



window_t* OpenWindow(window_t* parent,uint32_t x, uint32_t y, uint32_t w, uint32_t h,uint64_t flags,char* title){
    window_t* window =(window_t*)executive->Alloc(sizeof(window_t));
    window->node.nodeType = NODE_WINDOW;
    window->node.name = title;
    window->node.priority = 0;
    window->screenTitle = NULL;
    
    Enqueue(&windowList, (node_t*)window);
    

    
    window->parent = parent;
    window->x = x;
    window->y = y;
    window->w = w;
    window->h = h;
    window->minWidth = 100;
    window->minHeight = 50;
    window->maxWidth = graphics.frameBuffer.width;
    window->maxHeight = graphics.frameBuffer.height;
    window->flags = flags;
    window->bitmap = graphics.NewBitmap(w, h);
    window->eventPort = NULL;
    GimmeZeroZero(window);
    
    
    uint32_t* p = window->bitmap->buffer;
    for(uint32_t i=0;i<w*h;++i){
        //p[i] = i;
        p[i] = intuition.backgroundColour;
    }
    
    InitList(&window->gadgetList);
    
    drawWindowDecoration(window);
    
    updateLayers(window);
    RedrawWindow(window);
    
    return window;
}

window_t* Request(){
    
    window_t* window = OpenWindow(NULL, 0,0,320,143,WINDOW_TITLEBAR | WINDOW_DRAGGABLE | WINDOW_DEPTH_GADGET| WINDOW_RESIZABLE,"System Request");
    graphics.DrawRect(window->bitmap,4,22,window->innerW-5,window->h - 26,intuition.white);
    graphics.DrawRect(window->bitmap,6,24,window->innerW-9,window->h - 30,intuition.blue);
    graphics.DrawRect(window->bitmap,8,26,window->innerW-13,window->h - 34,intuition.white);
    
    //fake gadgets
    graphics.DrawRect(window->bitmap,17,98,63,33,intuition.orange);
    graphics.DrawRect(window->bitmap,19,100,59,29,intuition.white);
    graphics.DrawRect(window->bitmap,19,102,59,25,intuition.blue);
    graphics.DrawRect(window->bitmap,21,104,55,21,intuition.white);
    
    graphics.DrawRect(window->bitmap,200+17,98,63,33,intuition.orange);
    graphics.DrawRect(window->bitmap,200+19,100,59,29,intuition.white);
    graphics.DrawRect(window->bitmap,200+19,102,59,25,intuition.blue);
    graphics.DrawRect(window->bitmap,200+21,104,55,21,intuition.white);
    
    return window;
    
}

void Plot(window_t* window,uint32_t x, uint32_t y, uint32_t colour){
    
   
    Lock(&window->clipRectsLock);
    for(uint32_t i = 0;i < window->clipRects; ++i){
        
        if(x > window->clipRect[i].x && x < (window->clipRect[i].x + window->clipRect[i].w) ){
            if(y > window->clipRect[i].y && y < (window->clipRect[i].y + window->clipRect[i].h) ){
                window->clipRect[i].needsUpdate = true;
                window->needsRedraw = true;
            }
        }
        
    }
  
    graphics.PutPixel(window->bitmap,x,y,colour);
    FreeLock(&window->clipRectsLock);
    
}

void PutChar(window_t* window, uint32_t x, uint32_t y, uint8_t character, uint32_t fColour, uint32_t bColour){
    
    
    Lock(&window->clipRectsLock);
       for(uint32_t i = 0;i < window->clipRects; ++i){
           
           uint32_t clipX1 = window->clipRect[i].x;
           uint32_t clipX2 = window->clipRect[i].x + window->clipRect[i].w;
           uint32_t clipY1 = window->clipRect[i].y;
           uint32_t clipY2 = window->clipRect[i].y + window->clipRect[i].h;
           
           if (clipX1 < x+8 && clipX2 > x && clipY1 < y+16 && clipY2 > y){
               window->clipRect[i].needsUpdate = true;
               window->needsRedraw = true;
           }
        }
    
    graphics.RenderGlyph(window->bitmap, topaz_font, x, y, character, fColour, bColour);
    FreeLock(&window->clipRectsLock);
}

void DrawRectangle(window_t* window,uint32_t x, uint32_t y, uint32_t w, uint32_t h, uint32_t colour){
    
    
    Lock(&window->clipRectsLock);
    for(uint32_t i = 0;i < window->clipRects; ++i){
        
        uint32_t clipX1 = window->clipRect[i].x;
        uint32_t clipX2 = window->clipRect[i].x + window->clipRect[i].w;
        uint32_t clipY1 = window->clipRect[i].y;
        uint32_t clipY2 = window->clipRect[i].y + window->clipRect[i].h;
        
        uint32_t winX1 = x;
        uint32_t winX2 = x + w;
        uint32_t winY1 = y;
        uint32_t winY2 = y + h;
        
        if (clipX1 < winX2 && clipX2 > winX1 && clipY1 < winY2 && clipY2 > winY1){
            window->clipRect[i].needsUpdate = true;
            window->needsRedraw = true;
        }
     }
    
    graphics.DrawRect(window->bitmap,x, y, w, h, colour);
    FreeLock(&window->clipRectsLock);
}



void OpenIntuition(library_t* lib){
    
    lib->openCount += 1;
    
}

void CloseIntuition(library_t* lib){
    
    lib->openCount -= 1;
    
    if(lib->openCount < 0){
        //do something as the library is no longer needed
        lib->openCount = 0;
    }
    
}


void InitIntuition(library_t* library){
    //this is a called by exec's AddLibrary
    
    library->node.name = "intuition.library";
    library->node.nodeType = NODE_LIBRARY;
    
    InitList(&windowList);
    screenTitle = NULL;
    
    //clear screen
    graphics.DrawRect(&graphics.frameBuffer, 0,0,graphics.frameBuffer.width,graphics.frameBuffer.height,intuition.backgroundColour);
    drawTitleBar();
    
    
    //DrawRectangle(screen,0,0,graphics.frameBuffer.width,20,intuition.black);
    
    mouseVisible = true;
    drawMouse();
    
    
}

void LoadIntuitionLibrary(){

    
    inputStruct.focused = NULL;
    //intuition.library.node.name = "intuition.library";
    intuition.library.version   = 1;
    intuition.library.Init      = InitIntuition;
    intuition.library.Open      = OpenIntuition;
    intuition.library.Close     = CloseIntuition;
    intuition.screenWidth       = graphics.frameBuffer.width;;
    intuition.screenHeight      = graphics.frameBuffer.height;
    intuition.blue              = graphics.Colour(0x00,0x55,0xAA,0xFF);
    intuition.white             = graphics.Colour(0xFF,0xFF,0xFF,0xFF);
    intuition.orange            = graphics.Colour(0xFF,0x88,00,0xFF);
    intuition.black             = graphics.Colour(0x00,0x00,0x22,0xFF);
    intuition.grey              = graphics.Colour(171,187,205,0xFF);
    intuition.red               = graphics.Colour(217,46,31,0xFF);
    intuition.grey2             = graphics.Colour(170,170,170,0xFF);
    intuition.blue2             = graphics.Colour(102,136,187,0xFF);
    intuition.backgroundColour  = intuition.blue;
    intuition.mouseImage        = macMousePointer;
    intuition.OpenWindow        = OpenWindow;
    intuition.SetScreenTitle    = SetScreenTitle;
    intuition.MoveWindow        = MoveWindow;
    intuition.ResizeWindow      = ResizeWindow;
    intuition.WindowToBack      = WindowToBack;
    intuition.WindowToFront     = WindowToFront;
    intuition.Focus             = Focus;
    intuition.Plot              = Plot;
    intuition.PutChar           = PutChar;
    intuition.DrawRectangle     = DrawRectangle;
    intuition.ClearWindow       = ClearWindow;
    intuition.Request           = Request;

    
}


