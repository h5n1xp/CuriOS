rm ./disk.vdi
VBoxManage convertdd ./disk.img ./disk.vdi --format VDI
