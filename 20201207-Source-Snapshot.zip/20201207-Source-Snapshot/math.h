//
//  math.h
//
//  Created by Matt Parsons on 13/11/2020.
//  Copyright © 2020 Matt Parsons. All rights reserved.
//

#ifndef math_h
#define math_h

#include "stdheaders.h"

#endif /* math_h */
