//
//  cli.c
//
//  Created by Matt Parsons on 10/11/2020.
//  Copyright © 2020 Matt Parsons. All rights reserved.
//

#include "cli.h"

#include "string.h"
#include "list.h"
#include "memory.h"
#include "intuition.h"

#include "ata.h"
#include "fat_handler.h"
#include "dos.h"

#include "SystemLog.h"



int32_t width;
int32_t height;
int32_t x;
int32_t y;

uint32_t conCurX;
uint32_t conCurY;

intuition_t* intuibase;

uint32_t bufferIndex;


char consoleBuffer[4096];

void ConsoleClearCursor(window_t* window){

    intuibase->DrawRectangle(window,conCurX, conCurY, 8, 16, window->backgroundColour);
}



void ConsoleDrawCursor(window_t* window, uint32_t x, uint32_t y){
    conCurX = (x*8)+4;
    conCurY = (y*16)+22;
    intuibase->DrawRectangle(window,conCurX, conCurY, 8, 16, window->highlightColour);
}

void ConsoleRedraw(window_t* window);


void ConsoleScroll(window_t* window){
    
    
    if(bufferIndex >= 4095){
        
        for(int i = 0 ; i< 2048;++i){
            
            consoleBuffer[i] = consoleBuffer[i+2048];
            
        }
        
        bufferIndex = 2047;
        
    }
    
    ConsoleRedraw(window);
}



void ConsolePutCharPrivate(window_t* window, char character){
    
    //Doesn't record the character placement in the console buffer
    
    ConsoleClearCursor(window);
    
    if(character=='\n'){
        ++y;
        x=0;
        
        if(y >= height){
               ConsoleScroll(window);
               //y -= 1;
           }
        
    }else if(character=='\t'){
        
        x = (x + 7) & 0xFFF8;
        
    }else{
    
        intuibase->PutChar(window,(x*8)+4,(y*16)+22,character,window->foregroundColour,window->backgroundColour);
    
        x++;
        if(x>width){
            y++;
            
            if(y >= height){
                ConsoleScroll(window);
                //y -= 1;
            }
            
            x=0;
        }
    
    }
    ConsoleDrawCursor(window,x,y);
}

void ConsolePutChar(window_t* window, char character){
    
    
    consoleBuffer[bufferIndex++] = character;
    if(bufferIndex >= 4095){
        
        for(int i = 0 ; i < 2048;++i){
            
            consoleBuffer[i] = consoleBuffer[i+2048];
            
        }
        
        bufferIndex = 2048;
        
    }
    
    
    ConsolePutCharPrivate(window, character);

    
}

void ConsoleRedraw(window_t* window){
 
    //Count lines
    int32_t lines = 0;
    uint32_t i = 0;
    char c = 0;
    
    int32_t lineLength = 0;
    
    do{
        c = consoleBuffer[i];
        lineLength += 1;
        
        if(c =='\n'){
            lines += 1;
            lineLength = 0;
        }
        
        if(lineLength >= width){
            lines += 1;
            lineLength = 0;
        }
        
        i += 1;
    }while(i<bufferIndex);
    
    if(lines >= height){
    
        uint32_t startline = lines - height;

        lines = 0;
        i = 0;
        c = 0;
    
        uint32_t lineLength = 0;
    
        do{
            c = consoleBuffer[i];
            lineLength += 1;
        
            if(c =='\n'){
                lines += 1;
                lineLength = 0;
            }
        
            if((uint32_t)lineLength >= (uint32_t)width){
                lines += 1;
                lineLength = 0;
            }
        
            i += 1;
        }while((uint32_t)lines <= startline);
    
    }else{
        i = 0;
    }
    
    x = 0;
    y = 0;
    
    intuibase->ClearWindow(window);
    
    for(; i<bufferIndex;++i){
        ConsolePutCharPrivate(window,consoleBuffer[i]);
    }

    
    
    
}

void ConsoleWriteString(window_t* window, char* str){
    
    uint32_t size = strlen(str);
    
    for (size_t i = 0; i < size; i++){
        ConsolePutChar(window,str[i]);
    }
    
    
}

void ConsoleWriteDec(window_t* window, uint32_t n){
    
    if (n == 0){
         //debug_putchar('0');
         ConsolePutChar(window,'0');
         return;
     }
     
     int32_t acc = n;
     char c[32];
     int i = 0;
     while (acc > 0){
         c[i] = '0' + acc%10;
         acc /= 10;
         i++;
     }
     
     c[i] = 0;
     
     char c2[32];
     c2[i--] = 0;
     int j = 0;
     while(i >= 0){
         c2[i--] = c[j++];
     }
     
     //debug_write_string(c2);
    ConsoleWriteString(window, c2);
    
}


void ConsoleWriteHex(window_t* window, uint32_t n){
    int32_t tmp;
     
    // debug_write_string("0x");
    ConsoleWriteString(window, "0x");
    
     char noZeroes = 1;
     
     int i;
     
     for (i = 28; i > 0; i -= 4){
         tmp = (n >> i) & 0xF;
         if (tmp == 0 && noZeroes != 0){
             continue;
         }
         
         if (tmp >= 0xA){
             noZeroes = 0;
             //debug_putchar(tmp - 0xA + 'a');
             ConsolePutChar(window,tmp - 0xA + 'a');
         }else{
             noZeroes = 0;
             //debug_putchar(tmp + '0');
             ConsolePutChar(window,tmp + '0');
         }
     }
     
     tmp = n & 0xF;
     if (tmp >= 0xA){
         //debug_putchar(tmp - 0xA + 'a');
         ConsolePutChar(window,tmp - 0xA + 'a');
     }else{
         //debug_putchar(tmp + '0');
         ConsolePutChar(window,tmp + '0');
     }
   
}


void ConsoleBackSpace(window_t* window){
    ConsoleClearCursor(window);
    x -= 1;
    bufferIndex -= 1;
    
    if(x<0){
        x = width;
        y -= 1;
    }
    ConsoleDrawCursor(window,x,y);
}




void ConsoleSize(window_t* window){
    width = (window->innerW / 8) - 2;
    height = ((window->innerH - 22) / 16) - 1;
}



// Command Interpretor ***************************************************************
dos_t* dosbase;
window_t* console;
uint32_t commandBufferIndex = 0;
char commandBuffer[512];
char lastCommand[512];


void processCommand(int commandLength){
    
    //remove leading spaces
    int start = 0;
    while(commandBuffer[start] == ' ' && start < commandLength){
        start++;
    }
    
    //count arguments
    int count = 1;  // there is alwasy one argument if we get to the process buffer stage
    for(int i=start;i<commandLength;++i){
        
        if(commandBuffer[i]==' ' && (commandBuffer[i+1]!=' ' && commandBuffer[i+1]!=0) ){
            count++;
        }
    }
   
    //create an argument pointer array
    char* arguments[count];
    
    arguments[0] = &commandBuffer[start];
    int pos = 0;
    for(int i = start;i<commandLength;++i){
        
        if(commandBuffer[i]==' ' && (commandBuffer[i+1]!=' ' && commandBuffer[i+1]!=0) ){
            pos++;
            commandBuffer[i]=0;
            arguments[pos] = &commandBuffer[i + 1];
        }else if(commandBuffer[i]==' '){
            commandBuffer[i]=0; // null terminate the argument
        }
        
    }
    
    
    //messy way to implment the dir command :-)
    if(strcmp(commandBuffer,"dir") == 0){
        
        if(count > 1){
            
            file_t* file = dosbase->Open(arguments[1],0);
            
            if(file == NULL){
            
                switch(executive->thisTask->dosError){
                    case DOS_ERROR_UNKNOWN_DEVICE:
                        intuition.Request();    //Throw a test Requestor :-)
                        ConsoleWriteString(console,"Unknown Device");
                        break;
                    case DOS_ERROR_DEVICE_NOT_SPECIFIED:
                        ConsoleWriteString(console,"Device not specified");
                        break;
                    case DOS_ERROR_UNABLE_TO_OPEN_DEVICE:
                        ConsoleWriteString(console,"Can't open device");
                        break;
                    case DOS_ERROR_OBJECT_NOT_FOUND:
                        ConsoleWriteString(console,"File not found!\n");
                        break;
                        
                    default:
                        ConsoleWriteString(console,"Unknown command ");
                        ConsoleWriteString(console,arguments[0]);
                        break;
                }
                
                
            }else{
                
                directoryStruct_t* ds = dosbase->Examine(file);
                
                if(ds==NULL){
                    
                    switch(executive->thisTask->dosError){
                        case DOS_ERROR_NOT_A_DIRECTORY:
                            ConsoleWriteString(console,"Not a directory!\n");
                            break;
                            
                        default:
                            ConsoleWriteString(console,"Um... An error occured!\n");
                            break;
                            
                    }
                    return;
                    
                }
                
                //Print directory using the returned structure
                directoryEntry_t* dt = ds->entry;

                
                for(uint32_t i = 0;i<ds->size;i++){
                    
                    ConsoleWriteString(console,"   ");
                    ConsoleWriteString(console,dt[i].name); ConsoleWriteString(console,"            \t ");
                    
                    
                    if(dt[i].isDir){
                        ConsoleWriteString(console,"(dir)");
                    }else{
                        ConsoleWriteDec(console,dt[i].fileSize);
                    }
                    
                    //ConsoleWriteString(console," | Cluster: ");
                    //ConsoleWriteDec(console,dt[i].cluster);
                    
                    if(dt[i].isHidden){
                        ConsoleWriteString(console," (Hidden)");
                    }
                    
                    ConsolePutChar(console,'\n');
                }
                executive->FreeMem(ds);//free the directory structure returned by Examine()
                
                dosbase->Close(file);
            }
            
            ConsolePutChar(console,'\n');
            
        }else{
            ConsoleWriteString(console,"No path provided.\n");
        }
        
        return;
        
    }
    
    ConsoleWriteString(console,"Unknown Command ");
    ConsoleWriteString(console,arguments[0]);
    ConsolePutChar(console,'\n');
    
    return;
        
        file_t* file = dosbase->Open(arguments[0],0);
        
        if(file == NULL){
        
            switch(executive->thisTask->dosError){
                case DOS_ERROR_UNKNOWN_DEVICE:
                    intuition.Request();    //Throw a test Requestor :-)
                    ConsoleWriteString(console,"Unknown Device");
                    break;
                case DOS_ERROR_DEVICE_NOT_SPECIFIED:
                    ConsoleWriteString(console,"Device not specified");
                    break;
                case DOS_ERROR_UNABLE_TO_OPEN_DEVICE:
                    ConsoleWriteString(console,"Can't open device");
                    break;
                case DOS_ERROR_OBJECT_NOT_FOUND:
                    ConsoleWriteString(console,"File not found!\n");
                    break;
                    
                default:
                    ConsoleWriteString(console,"Unknown command ");
                    ConsoleWriteString(console,arguments[0]);
                    break;
            }
            
            
        }else{
            
            directoryStruct_t* ds = dosbase->Examine(file);
            
            if(ds==NULL){
                
                switch(executive->thisTask->dosError){
                    case DOS_ERROR_NOT_A_DIRECTORY:
                        ConsoleWriteString(console,"Not a directory!\n");
                        break;
                        
                    default:
                        ConsoleWriteString(console,"Um... An error occured!\n");
                        break;
                        
                }
                return;
                
            }
            
            //Print directory using the returned structure
            directoryEntry_t* dt = ds->entry;
            
            //debug_write_string("Returned size ");
            //debug_write_dec(ds->size);

            
            for(uint32_t i = 0;i<ds->size;i++){
                
                ConsoleWriteString(console,"    ");
                ConsoleWriteString(console,dt[i].name); ConsoleWriteString(console,"   \t\t\t");
                
                
                if(dt[i].isDir){
                    ConsoleWriteString(console,"(dir)");
                }else{
                    ConsoleWriteDec(console,dt[i].fileSize);
                }
                
                ConsoleWriteString(console," | Cluster: ");
                ConsoleWriteDec(console,dt[i].cluster);
                
                if(dt[i].isHidden){
                    ConsoleWriteString(console," (Hidden)");
                }
                
                ConsolePutChar(console,'\n');
            }
            executive->FreeMem(ds);//free the directory structure returned by Examine()
            
            dosbase->Close(file);
        }
  
    
    
    ConsolePutChar(console,'\n');
}








int CliEntry(void){
    
    
    //The Boot Task should be responsible for loading the initial Libraries and devices into memory.

    //setup the ata device as early as possible before the DOS Library, if the ATA device isn't ready DOS will hang the machine.
    LoadATADevice();
    executive->AddDevice((device_t*)&ata);
    //executive->Reschedule();    //Yeld the CPU while the ATA device sets up

    intuibase = (intuition_t*) executive->OpenLibrary("intuition.library",0);
    
    console = intuibase->OpenWindow(NULL,0,22,intuibase->screenWidth,(intuibase->screenHeight/2)-24,WINDOW_TITLEBAR | WINDOW_DRAGGABLE | WINDOW_DEPTH_GADGET | WINDOW_RESIZABLE, "BootShell");
    console->eventPort = executive->CreatePort("Event Port");

    ConsoleSize(console);
    x = 0;
    y = 0;
    conCurX = (x*8)+4;
    conCurY = (y*16)+22;

     // This bootshell task, this should be responsible for much of the system set up
    
    ConsoleWriteString(console,"Copyright ");
    ConsolePutChar(console,169);
    ConsoleWriteString(console,"2021 Matt Parsons.\nAll rights reserved.\nRelease 0.45a\n\n");
    

 
    
    //Initilise and open DOS library
    LoadDOSLibrary();   //Load DOS Library into memory (already done here) and call its "LoadXLibrary()" function
    executive->AddLibrary((library_t*)&dos);    // add DOS to the Exec library list.
    dosbase = (dos_t*) executive->OpenLibrary("dos.library",0);    // never use a library without opening it first

    
    debug_write_string("CLI MESSAGE: dir command works, usage - dir <path> ( example: dir dh0:boot/grub )");
    ConsoleWriteString(console,"1> ");
    while(1){
        executive->WaitPort(console->eventPort);
        intuitionEvent_t* event = (intuitionEvent_t*) executive->GetMessage(console->eventPort);
    
        while(event != NULL){
        
            if(event->flags & WINDOW_EVENT_RESIZE){
                intuibase->ResizeWindow(console, console->w - event->mouseXrel, console->h - event->mouseYrel);
                ConsoleSize(console);
            }
            
            if(event->flags & WINDOW_EVENT_RESIZE_END){
                
                ConsoleRedraw(console);
            }
            
            
            if(event->flags & WINDOW_EVENT_KEYDOWN){
            

                
                    if(event->rawKey == 0xE){
                        //delete key
                        
                        if(commandBufferIndex > 0){
                            commandBufferIndex -=1;
                            ConsoleBackSpace(console);
                        }
                        
                    }else if(event->rawKey == 0x1C){
                        // enter key
                        ConsolePutChar(console,'\n');   // newline as enter has been pressed
                        commandBuffer[commandBufferIndex]= 0; // append a NULL to the command buffer

                        
                        if(commandBufferIndex>0){
                            
                           processCommand(commandBufferIndex);
                
                        }
                        

                        commandBufferIndex  = 0;
                        ConsoleWriteString(console,"1> ");
                    }else if(event->rawKey == 0x48){
                        //up cursor
                    }else{
                        if(commandBufferIndex < 255){
                            commandBuffer[commandBufferIndex] = event->scancode;
                            commandBufferIndex += 1;
                            ConsolePutChar(console, event->scancode);
                        }
                    }
        
                
            }

            
            executive->ReplyMessage((message_t*)event); // Always reply a message as soon as possible
            //get next message
            event = (intuitionEvent_t*) executive->GetMessage(console->eventPort);
        }
    
    }
}
