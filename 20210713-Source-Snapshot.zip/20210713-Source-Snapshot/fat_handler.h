//
//  fat_handler.h
//
//  Created by Matt Parsons on 27/11/2020.
//  Copyright © 2020 Matt Parsons. All rights reserved.
//

#ifndef fat_handler_h
#define fat_handler_h

#include "stdheaders.h"
#include "device.h"
#include "dos.h"

#include "dosCommonStructures.h"

typedef struct{
    device_t device;
    void (*SetHandler)(dosEntry_t* entry);
} fatHandler_t;





extern fatHandler_t fatHandler;
void LoadFATHandler(void);


//Internal functions exposed while the hander features aren't used.
void getPartitionData(file_t* file, int partitionNumber);
void getVolumeBootRecord(file_t* file);
void readBlock(file_t* file, uint32_t block);
directoryStruct_t* readDir(file_t* file,uint32_t block);

void SetHandler(dosEntry_t*);
uint32_t FATGetPartitionLBA(int partitionNumber);



#endif /* fat_handler_h */
