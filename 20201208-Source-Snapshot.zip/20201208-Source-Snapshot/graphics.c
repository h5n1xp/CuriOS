//
//  graphics.c
//  GFXConvert
//
//  Created by Matt Parsons on 25/10/2020.
//  Copyright © 2020 Matt Parsons. All rights reserved.
//

#include "graphics.h"
#include "font.h"


graphics_t graphics;


uint32_t get_pixel16(bitmap_t* bm, uint32_t x,uint32_t y){
    uint16_t* p = bm->buffer;
    return (uint32_t)p[(y * bm->width) + x];
}

void put_pixel16(bitmap_t* bm, uint32_t x,uint32_t y, uint32_t colour){

       //clipping
       if(x>=bm->width){
           return;
       }
    
       if(y>=bm->height){
           return;
       }

    uint16_t* p = bm->buffer;
    p[(y * bm->width) + x] = (uint16_t)colour;
}


uint32_t get_pixel32(bitmap_t* bm, uint32_t x,uint32_t y){
    //Lock(&bm->lock);
    //executive->Forbid();
    uint32_t* p = bm->buffer;
    //executive->Permit();
    //FreeLock(&bm->lock);
    return (uint32_t)p[(y * bm->width) + x];
}

void put_pixel32(bitmap_t* bm, uint32_t x,uint32_t y, uint32_t colour){
    //Lock(&bm->lock);
    //executive->Forbid();
    //clipping
    if(x>=bm->width){ //can't be negative
        //executive->Permit();
        //FreeLock(&bm->lock);
        return;
    }
 
    if(y>=bm->height){ //can't be negative
        //executive->Permit();
        //FreeLock(&bm->lock);
        return;
    }

    uint32_t* p = bm->buffer;
    p[(y * bm->width) + x] = colour;
    //executive->Permit();
    //FreeLock(&bm->lock);
}


void PutPixelFast(bitmap_t* bm, uint32_t x,uint32_t y, uint32_t colour){
    //Lock(&bm->lock);
    //executive->Forbid();
    //No Clipping... You have been warned
    uint32_t* p = bm->buffer;
    p[(y * bm->width) + x] = colour;
    //executive->Permit();
    //FreeLock(&bm->lock);
}



uint32_t colour16(uint8_t red,uint8_t green, uint8_t blue,uint8_t alpha){
    
    if(alpha ==255){
        red = red >> 3;
        green = green >> 3;
        blue = blue >> 3;
    }else{
        return 0;
    }
    
    
    return (red << 12) | (green << 6) | blue;
    
}

uint32_t colour32(uint8_t red, uint8_t green, uint8_t blue,uint8_t alpha){
    
    uint32_t retVal = 0;
    retVal |=(alpha << 24);
    retVal |=(red << 16);
    retVal |=(green << 8);
    retVal |= blue;
    return retVal;//(255 << 24) | (red << 16) | (green << 8) | blue;
    
}



/*
void CopyRect(uint32_t sx,uint32_t sy,uint32_t dx,uint32_t dy,uint32_t w, uint32_t h){
    
    
    for(int y=0; y<)
    
    
}
*/

//*************** Assembly highspeed copy
inline void movsd(void* dst, const void* src, size_t size){
    asm volatile("rep movsl" : "+D"(dst), "+S"(src), "+c"(size) : : "memory");
}

void BlitRect(bitmap_t* source, uint32_t sx, uint32_t sy, uint32_t w, uint32_t h, bitmap_t* dest, uint32_t x, uint32_t y){
    
    //Lock(&source->lock);
    //Lock(&dest->lock);
    //executive->Forbid();
    
    uint32_t* s = source->buffer;
    uint32_t* d = dest->buffer;
    
    
    if(x+w >= dest->width){w = dest->width - x;}
    if(y+h >= dest->height){h = dest->height - y;}
    
    if(w < 1 || h < 1){
        //executive->Permit();
        //FreeLock(&dest->lock);
        //FreeLock(&source->lock);
        return;
    }
    
    for(uint32_t by=0;by<h;++by){
        
        /*
        for(uint32_t bx=0;bx<w;++bx){
            
            d[((by+y)*dest->width)+bx+x] = s[((by+sy)*source->width)+bx+sx];
        }
        */
        
        movsd(&d[((by+y)*dest->width)+x],&s[((by+sy)*source->width)+sx],w);
        
    }
    
    
    
  /*
  for(uint32_t by=0;by<h;++by){
      for(uint32_t bx=0;bx<w;++bx){
          
          PutPixel(dest,bx+x,by+y, GetPixel(source,bx+sx,by+sy));

      }

  }
   */
    //executive->Permit();
    //FreeLock(&dest->lock);
    //FreeLock(&source->lock);
}

void BlitBitmap(bitmap_t* source, bitmap_t* dest, uint32_t x, uint32_t y){
    //Lock(&source->lock);
    //Lock(&dest->lock);
    //executive->Forbid();
    
    uint32_t* s = source->buffer;
    uint32_t* d = dest->buffer;
    
    
    uint32_t w = source->width;
    uint32_t h = source->height;
    
    if(x+w >= dest->width){w = dest->width - x;}
    if(y+h >= dest->height){h = dest->height - y;}
    
    if(w < 1 || h < 1){
        //executive->Permit();
        //FreeLock(&dest->lock);
        //FreeLock(&source->lock);
        return;
    }
    
    
  for(uint32_t by=0;by<h;++by){
      /*
      for(uint32_t bx=0;bx<w;++bx){
          
          // d[ ((by+y)*dest->width) + bx+x] = s[(by*source->width)+x];
          
          // PutPixel(dest,bx+x,by+y, GetPixel(source,bx,by));

      }
       */
    movsd(&d[((by+y)*dest->width)+x],&s[(by*source->width)],w);
  }
    //executive->Permit();
    //FreeLock(&dest->lock);
    //FreeLock(&source->lock);
}

bitmap_t* NewBitmap(uint32_t w,uint32_t h){
    
    bitmap_t* bm = (bitmap_t*)executive->Alloc( (w*h*4) + sizeof(bitmap_t));
    bm->node.nodeType = NODE_BITMAP;
    bm->width = w;
    bm->height = h;
    bm->bpp = 32;
    void* buffer = bm + 1;
    bm->buffer = buffer;
    return bm;
    
}

void FreeBitmap(bitmap_t* bitmap){
    executive->Dealloc((node_t*)bitmap);
}

bitmap_t* ResizeBitmap(bitmap_t* old,uint32_t w, uint32_t h){
    
    if(old->width > w && old->height > h){
        return old;
    }
    
     bitmap_t* bm = (bitmap_t*)executive->Alloc( (w*h*4) + sizeof(bitmap_t));
    
    return bm;
}

void DrawRect(bitmap_t* bm, uint32_t x, uint32_t y, uint32_t w, uint32_t h, uint32_t rgb){
    //Lock(&bm->lock);
    //executive->Forbid();
    uint32_t height = y + h;
    uint32_t width  = x + w;
   
    uint32_t* d = (uint32_t*)bm->buffer;
    
    if(height >= bm->height){height = bm->height;}
    if(width  >= bm->width){width=bm->width;}
    
    for(uint32_t j=y;j<height;++j){
        for(uint32_t i=x;i<width;++i){
        
            d[(j*bm->width)+i] = rgb;
        }
    }
    //executive->Permit();
    //FreeLock(&bm->lock);
}

void ClearBitmap(bitmap_t* bm,uint32_t rgb){
    
    uint32_t size = bm->width * bm->height;
    uint32_t* d = bm->buffer;
    
    do{
        size -=1;
        d[size] = rgb;
    }while(size > 0);
    
}

void RenderGlyph(bitmap_t* bm, uint8_t* font, uint32_t x, uint32_t y, uint8_t character, uint32_t fColour, uint32_t bColour){

           
           for(int cy=0;cy<16;++cy){
                   
               //uint8_t font_row = font[((cy+16)*256)+character]; //Topaz New
                uint8_t font_row = font[((cy)*256)+character];    //Topas Old
               
               
               
                   if( font_row & 0x80){
                       PutPixelFast(bm,x,y+cy,fColour);
                   }else{
                       PutPixelFast(bm,x,y+cy,bColour);
                   }
                   
                   if(font_row & 0x40){
                        PutPixelFast(bm,x+1,y+cy,fColour);
                   }else{
                        PutPixelFast(bm,x+1,y+cy,bColour);
                   }
    
                   if(font_row & 0x20){
                        PutPixelFast(bm,x+2,y+cy,fColour);
                   }else{
                        PutPixelFast(bm,x+2,y+cy,bColour);
                   }
                   
                   if(font_row & 0x10){
                        PutPixelFast(bm,x+3,y+cy,fColour);
                   }else{
                        PutPixelFast(bm,x+3,y+cy,bColour);
                   }
                   
                   if(font_row & 0x08){
                        PutPixelFast(bm,x+4,y+cy,fColour);
                   }else{
                        PutPixelFast(bm,x+4,y+cy,bColour);
                   }
                                  
                   if(font_row & 0x04){
                        PutPixelFast(bm,x+5,y+cy,fColour);
                   }else{
                        PutPixelFast(bm,x+5,y+cy,bColour);
                   }
                   
                   if(font_row & 0x02){
                        PutPixelFast(bm,x+6,y+cy,fColour);
                   }else{
                        PutPixelFast(bm,x+6,y+cy,bColour);
                   }
                                  
                   if(font_row & 0x01){
                        PutPixelFast(bm,x+7,y+cy,fColour);
                   }else{
                        PutPixelFast(bm,x+7,y+cy,bColour);
                   }
               
           }

}

void RenderString(bitmap_t* bm,uint32_t x,uint32_t y,char* str,uint32_t fColour,uint32_t bColour){
    
    uint32_t index = 0;
    
    while (str[index] != 0) {
        
        RenderGlyph(bm, topaz_font,x,y,str[index],fColour,bColour);
        x += 8;
        index += 1;
    }
    
}


void DrawHorizontalLine(bitmap_t* bm, uint32_t x, uint32_t y,uint32_t length, uint32_t rgb){
  
    do{
        --length;
        put_pixel32(bm,x+length,y,rgb);
    }while(length>0);
    
}

void DrawVerticalLine(bitmap_t* bm, uint32_t x, uint32_t y,uint32_t length, uint32_t rgb){
    
    do{
        --length;
        put_pixel32(bm,x,y+length,rgb);
    }while(length>0);
    
    
}

void DrawDiagonalLine(){
    
}



void DrawSprite(sprite_t* sprite, uint32_t sx, uint32_t sy){
    uint32_t index = 0;
    uint32_t* p = graphics.frameBuffer.buffer;
    uint32_t* b = sprite->backingStore;
    
    //save background
    uint32_t w = sprite->width;
    uint32_t h = sprite->height;
    
    if(w >= graphics.frameBuffer.width){w = graphics.frameBuffer.width - sx;}
    if(h >= graphics.frameBuffer.height){h = graphics.frameBuffer.height - sy;}
    
    for(uint32_t y = 0; y<h;++y){
        
        movsd(&b[index],&p[((sy+y)*graphics.frameBuffer.width)+sx],w);
        
        index += sprite->width;
        
    }
   /*
    //draw pointer
    w = sx + sprite->width;
    h = sy + sprite->height;
    
    if(w >= graphics.frameBuffer.width){w = graphics.frameBuffer.width;}
    if(h >= graphics.frameBuffer.height){h = graphics.frameBuffer.height;}
    
    index = 0;
    for(uint32_t y = sy;y < (uint32_t)mouseY+22;++y){
        for(uint32_t x = sx; x < (uint32_t)mouseX+22;++x){
            
            if(x<graphics.frameBuffer.width && y<graphics.frameBuffer.height){
                if(intuition.mouseImage[index] == 1){
                    p[(y * graphics.frameBuffer.width) + x] =  0;   //black
                }
                
                if(intuition.mouseImage[index] == 2){
                    p[(y * graphics.frameBuffer.width) + x] =  intuition.grey;
                }
                
                if(intuition.mouseImage[index] == 3){
                    p[(y * graphics.frameBuffer.width) + x] =  intuition.red;
                }
                
                if(intuition.mouseImage[index] == 4){
                    p[(y * graphics.frameBuffer.width) + x] =  intuition.white;
                }
                
            }
            index += 1;
        }
    }
    */
}

void ClearSprite(sprite_t* sprite){
    
    volatile uint32_t w = sprite->width;

    w = w + 1;
    
}


void InitGraphics(library_t* library){
    //perhaps check for a proper gfx card here?
    library->node.nodeType = NODE_LIBRARY;
    library->node.name  = "graphics.library";
}

void OpenGraphics(library_t* library){
    
    library->openCount += 1;
    
}

void LoadGraphicsLibrary(multiboot_info_t* mbd){
    //Graphics version
    
    //graphics.library.node.name  = "graphics.library";
    graphics.library.Init       = InitGraphics;
    graphics.library.Open       = OpenGraphics;
    
    if(mbd->framebuffer_addr != 0){
        
        graphics.frameBuffer.width = mbd->framebuffer_width;
        graphics.frameBuffer.height= mbd->framebuffer_height;
        
        void_ptr pointer = (void_ptr)mbd->framebuffer_addr;
        graphics.frameBuffer.buffer =(void*) pointer;
        
        graphics.frameBuffer.bpp = mbd->framebuffer_bpp;
        
        if(mbd->framebuffer_bpp == 16){
            /*
            blue = colour16(0x00,0x55,0xAA,0xFF);
            white = colour16(0xFF,0xFF,0xFF,0xFF);
            orange = colour16(0xFF,0x88,00,0xFF);
            black = colour16(0x00,0x00,0x22,0xFF);
        
            grey = colour16(171,187,205,0xFF);
            red = colour16(217,46,31,0xFF);
        
            colour = colour16;
             */
        }
        
        if(mbd->framebuffer_bpp == 32){
            
            graphics.NewBitmap      = NewBitmap;
            graphics.FreeBitmap     = FreeBitmap;
            graphics.Colour         = colour32;
            graphics.GetPixel       = get_pixel32;
            graphics.PutPixel       = put_pixel32;
            graphics.RenderGlyph    = RenderGlyph;
            graphics.RenderString   = RenderString;
            graphics.DrawRect       = DrawRect;
            graphics.BlitBitmap     = BlitBitmap;
            graphics.BlitRect       = BlitRect;
            graphics.ClearBitmap    = ClearBitmap;
        }
        
        
    }
    

}
