//
//  dos.h
//
//  Created by Matt Parsons on 20/11/2020.
//  Copyright © 2020 Matt Parsons. All rights reserved.
//

#ifndef dos_h
#define dos_h

#include "stdheaders.h"
#include "library.h"
#include "device.h"
#include "list.h"


//The dosEntry is currently a bit of a dumping dround for variables,
// many of which (especially the file system specific ones) will be
// moved into the handler itself once the code works.
typedef struct{
    node_t node;
    
    char* handlerName;
    uint32_t handlerNumber;     //partition number
    uint32_t startBlock;        //LBA offset to partition
    uint32_t totalBlocks;
    uint32_t rootBlock;
    uint32_t dosType;           // information for the handler.
    uint32_t sectorSize;        // normal size is 512bytes
    
    uint32_t sectorsPerCluster; // Only Valid on FAT partitions
    uint32_t sectorsPerFAT;     // Only Valid on FAT Partitions
    uint32_t dataArea;          // Only Valid on FAT Partitions
    
    char* deviceName;
    uint32_t unitNumber;
    
}dosEntry_t;

typedef struct{
    char* fileName;
    uint64_t fileSize;
    uint64_t numberOfBlocks;
    uint64_t startBlock;
    ioRequest_t* handlerRequest;
}file_t;


typedef struct{
    library_t library;
    list_t dosList;
    void (*AddDosEntry)(dosEntry_t* entry);
    file_t* (*Open)(char* fileName, uint64_t attributes);
}dos_t;


extern dos_t dos;


void LoadDOSLibrary();

#endif /* dos_h */
