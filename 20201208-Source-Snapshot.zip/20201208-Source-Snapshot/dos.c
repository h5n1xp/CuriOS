//
//  dos.c
//
//  Created by Matt Parsons on 20/11/2020.
//  Copyright © 2020 Matt Parsons. All rights reserved.
//

#include "dos.h"
#include "memory.h"

#include "ata.h"
#include "fat_handler.h"
#include "string.h"

#include "SystemLog.h"

dos_t dos;




file_t* Open(char* fileName, uint64_t attributes){
    
    return NULL;
    
}

void InitDOS(library_t* library){
    //called by AddLibrary(), does the library set up.
    
    InitList(&dos.dosList);
    library->node.name = "dos.library";
 
    //The DOS.library will need to access the disks
    //setup the ata device
    LoadATADevice();
    executive->AddDevice((device_t*)&ata);
    
    //The boot disk will be FAT32
    LoadFATHandler();
    executive->AddDevice((device_t*)&fatHandler);
    
}

void OpenLib(library_t* lib){
    //dos.library.openCount +=1;
    lib->openCount +=1;
    
    //initilise the DOS Message port of the calling task
    task_t* task  = executive->thisTask;
    task->dosPort = executive->CreatePort(NULL);
    
}


void CloseLib(library_t* lib){
    //dos.library.openCount -=1;
    lib->openCount -=1;
    
    //remove DOS message port
    task_t* task  = executive->thisTask;
    executive->DeletePort((messagePort_t*)task->dosPort);
}

void AddDosEntry(dosEntry_t* entry){

    //need to setup the requested unit.
    
    AddTail(&dos.dosList,(node_t*) entry);
    
    ioRequest_t* handlerRequest = executive->CreateIORequest(NULL,sizeof(ioRequest_t));
    uint32_t error = executive->OpenDevice(entry->handlerName,entry->handlerNumber,handlerRequest,0);
    
    if(error == DEVICE_ERROR_DEVICE_NOT_FOUND){
        debug_write_string("Handler Not Found\n");
        return;
    }
    
    //if we get this far we know the fat handler has opened.
    fatHandler_t* handler = (fatHandler_t*)handlerRequest->device;
    handler->SetHandler(entry);

}


void LoadDOSLibrary(){
    
    dos.library.Init    = InitDOS;
    dos.library.Open    = OpenLib;
    dos.library.Close   = CloseLib;
    dos.AddDosEntry     = AddDosEntry;
    
}
