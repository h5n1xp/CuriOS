//
//  fat_handler.c
//
//  Created by Matt Parsons on 27/11/2020.
//  Copyright © 2020 Matt Parsons. All rights reserved.
//

#include "fat_handler.h"
#include "memory.h"

#include "SystemLog.h"


typedef struct{
    uint8_t boot_flag;
    uint8_t starting_head;
    uint16_t starting_sector;
    uint8_t system_id;
    uint8_t ending_head;
    uint16_t ending_sector;
    uint32_t starting_block;
    uint32_t total_blocks;
} mbr_partition_entry;

typedef struct{
    mbr_partition_entry first;
    mbr_partition_entry second;
    mbr_partition_entry third;
    mbr_partition_entry fourth;
} mbr_partition_table;


struct volume_boot_record{
    uint8_t  start[3];
    uint8_t  identifier[8];
    uint16_t bytes_per_sector;
    uint8_t  sectors_per_cluster;
    uint16_t reserved_sectors;
    uint8_t  number_of_file_allocation_tables;
    uint16_t number_of_directory_entries;
    uint16_t sector_count;
    uint8_t  media_descriptor_type;
    uint16_t sectors_per_fat_old;
    uint16_t sectors_per_track;
    uint16_t heads_per_media;
    uint32_t starting_block;
    uint32_t large_sector_count;
} __attribute__((packed));
typedef struct volume_boot_record volume_boot_record_t;


struct volume_boot_record_ext16{
    uint8_t drive_number;
    uint8_t NT_flags;
    uint8_t signature;          //if this is 0x28 0r 0x29 then we have ex16
    uint32_t VolumeID;
    uint8_t volume_label[11];
    uint8_t FAT32[8];           // always FAT32, nothing depends upon this
    uint8_t boot_code[448];
    uint16_t bootable_signature;
} __attribute__((packed));

typedef struct volume_boot_record_ext16 vbr_ext16_t;



struct volume_boot_record_ext32{
    uint32_t sectors_per_fat;
    uint16_t flags;
    uint16_t FAT_version;
    uint32_t cluster_number_of_root_directory;
    uint16_t sector_number_of_FSInfo;
    uint16_t sector_number_of_backup_boot_sector;
    uint8_t  reserved[12];
    uint8_t  drive_number;
    uint8_t  NT_flags;
    uint8_t  signature;         //if this has the value 0x28 or 0x29 we have a FAT32 volume.
    uint32_t volume_id;
    uint8_t  volume_label[11];
    uint8_t  FAT32[8];          //Always contains the text FAT32, nothing depends upon this fact.
    uint8_t  boot_code[420];    //Of no use to any OS other than MSDos, I guess
    uint16_t bootable_signature;
} __attribute__((packed));

typedef struct volume_boot_record_ext32 vbr_ext32_t;




fatHandler_t fatHandler;

//VERY simple Filesystem handler, only supports the first partition, this will need to be replaced.
ioRequest_t* req;
messagePort_t* port;

int FATHanderTaskEntry(){
    
    port = executive->CreatePort(NULL); //doesn't need a name
    
    while(1){
        //executive->WaitPort(1);
        executive->Wait(1);
        
    }
    
    return 0;
}

void FATInit(){
    // called by AddDevice();
    fatHandler.device.library.node.name = "fat.handler";
    executive->InitList(&fatHandler.device.unitList);
    
    executive->AddTask(FATHanderTaskEntry,4096,5);
    
    /*
    unit_t* unit = (unit_t*)executive->Alloc(sizeof(unit_t));
    executive->AddTail(&fatHandler.device.unitList,(node_t*)unit);
    
    unit->messagePort = e
     */
}

void FATOpen(library_t* lib){
    lib->openCount += 1;
}


void BeginIO(){
    
    
}

void readBlock(uint32_t block,uint8_t* buffer){
    
    messagePort_t* DOSPort = executive->thisTask->dosPort;
    
    req->command = CMD_READ;
    req->offset = block*512;
    req->length = 512;
    req->data = buffer;
    executive->SendIO(req);
    
    executive->WaitPort(DOSPort);
    executive->GetMessage(DOSPort);    //must GetMessage() to access it;
}

void SetHandler(dosEntry_t* entry){
    
    //set the underlying block device
    
    //unit_t* unit = executive->ItemAtIndex(&fatHandler.device.unitList,0);
    
    messagePort_t* DOSPort = executive->thisTask->dosPort;
    
    req = executive->CreateIORequest(DOSPort, sizeof(ioRequest_t));
    uint32_t error = executive->OpenDevice(entry->deviceName,entry->unitNumber,req,0);
    
    //read the device and find partiton number which mataches the handler number
    //set up the partiton details in the DOSEntry

    uint8_t* buffer = executive->AllocMem(512,0);
    
    readBlock(0,buffer);
    
    //Partition Table - only work with the first partition for now
    mbr_partition_table* table = (mbr_partition_table*) &buffer[446];
    
    entry->startBlock  = table->first.starting_block;
    entry->totalBlocks = table->first.total_blocks;
    
    //Get Volume Boot Rrecord, and extract the information we need
    readBlock(entry->startBlock,buffer);
    volume_boot_record_t* vbr = (volume_boot_record_t*)buffer;
    
    entry->sectorSize = vbr->bytes_per_sector;
    entry->sectorsPerCluster = vbr->sectors_per_cluster;
    
    vbr_ext16_t* vbr16 = (vbr_ext16_t*)&buffer[36];
    vbr_ext32_t* vbr32 = (vbr_ext32_t*)&buffer[36];
    if( (vbr16->signature == 0x28) || (vbr16->signature == 0x29) ){
        entry->sectorsPerFAT = vbr->sectors_per_fat_old;
        entry->rootBlock = 2 * entry->sectorsPerCluster;
        entry->dosType = 0xF16;
        debug_write_string("FAT16\n");
    }else{
        entry->sectorsPerFAT = vbr32->sectors_per_fat;
        entry->rootBlock  = vbr32->cluster_number_of_root_directory;
        entry->dosType = 0xF32;
        
        entry->dataArea   =  vbr->reserved_sectors + (vbr->number_of_file_allocation_tables * vbr32->sectors_per_fat);
        entry->dataArea  -= (vbr->sectors_per_cluster * 2);    //offset the data area pointer, so there is a 1:1 FAT to cluster relationship
        debug_write_string("FAT32\n");
    }
    
    
    debug_write_string("Starting block: ");debug_write_dec(entry->startBlock);
    debug_write_string("\nSize: ");debug_write_hex(entry->totalBlocks);
    debug_write_string("\nBytes Per Sector: ");debug_write_dec(entry->sectorSize);
    debug_write_string("\nSectors Per cluster: ");debug_write_dec(entry->sectorsPerCluster);
    debug_write_string("\nRoot cluster: ");debug_write_dec(entry->rootBlock);
    debug_write_string("\nDevice: ");debug_write_string(entry->deviceName); debug_write_string(" Opened by FAT\n");
    
    //clean up
    executive->Dealloc((node_t*)req);
    executive->FreeMem(buffer);
}

void LoadFATHandler(){

    fatHandler.device.library.Init  = FATInit;
    fatHandler.device.library.Open  = FATOpen;
    fatHandler.device.BeginIO       = BeginIO;
    fatHandler.SetHandler           = SetHandler;
}
