//
//  cli.h
//
//  Created by Matt Parsons on 10/11/2020.
//  Copyright © 2020 Matt Parsons. All rights reserved.
//

#ifndef cli_h
#define cli_h

#include "stdheaders.h"


int CliEntry(void);

#endif /* cli_h */
