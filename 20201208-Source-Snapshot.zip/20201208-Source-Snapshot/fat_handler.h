//
//  fat_handler.h
//
//  Created by Matt Parsons on 27/11/2020.
//  Copyright © 2020 Matt Parsons. All rights reserved.
//

#ifndef fat_handler_h
#define fat_handler_h

#include "stdheaders.h"
#include "device.h"
#include "dos.h"

typedef struct{
    device_t device;
    void (*SetHandler)(dosEntry_t* entry);
} fatHandler_t;

extern fatHandler_t fatHandler;

void LoadFATHandler(void);

#endif /* fat_handler_h */
